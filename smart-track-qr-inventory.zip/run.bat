@echo off
title SmartTrack QR School Inventory System
echo ========================================================
echo  Launching SmartTrack QR School Inventory System...
echo ========================================================
start "" "%~dp0index.html"
exit
