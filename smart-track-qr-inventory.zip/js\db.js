/**
 * SmartTrack Database Layer (Client-side Repository with LocalStorage / IndexedDB Persistence)
 * Starts BLANK and EMPTY for real production school data entry.
 * Includes User Accounts, Current/Past/Future Lifecycle Tracking.
 */
(function(window) {
  'use strict';

  var STORAGE_KEY = 'SMART_TRACK_SCHOOL_INVENTORY_DB_V2';
  var SESSION_KEY = 'SMART_TRACK_ACTIVE_SESSION';

  var DEFAULT_SCHOOL_PROFILE = {
    schoolName: "My School / Institution Name",
    subTitle: "Property Custodianship & Supply Office",
    campus: "Main Campus",
    address: "",
    custodianOfficer: "Property Custodian",
    custodianTitle: "Supply Officer",
    schoolHead: "School Principal / Campus Director",
    schoolHeadTitle: "Principal",
    currency: "₱",
    contactEmail: "",
    contactPhone: ""
  };

  var DEFAULT_CATEGORIES = [
    { id: 'cat-it', name: 'IT & Computing Equipment', code: 'IT', icon: '💻' },
    { id: 'cat-sci', name: 'Science & Laboratory Apparatus', code: 'SCI', icon: '🔬' },
    { id: 'cat-av', name: 'Audio-Visual & Multimedia', code: 'AV', icon: '📽️' },
    { id: 'cat-furn', name: 'Classroom & Office Furniture', code: 'FURN', icon: '🪑' },
    { id: 'cat-elec', name: 'Electrical & Facility Appliances', code: 'ELEC', icon: '⚡' },
    { id: 'cat-sport', name: 'Sports & PE Gear', code: 'SPT', icon: '🏀' },
    { id: 'cat-lib', name: 'Library Reference Assets', code: 'LIB', icon: '📚' }
  ];

  var DEFAULT_ROOMS = [
    { id: 'room-1', name: 'Computer Laboratory 1', building: 'Academic Bldg', floor: '1st Floor' },
    { id: 'room-2', name: 'Science Laboratory', building: 'Science Wing', floor: '1st Floor' },
    { id: 'room-3', name: 'Audio-Visual Center / AVR', building: 'Main Hall', floor: 'Ground Floor' },
    { id: 'room-4', name: 'Faculty Staff Room', building: 'Admin Bldg', floor: '2nd Floor' },
    { id: 'room-5', name: 'Classroom 101', building: 'Main Bldg', floor: '1st Floor' },
    { id: 'room-6', name: 'Central Supply Warehouse', building: 'Admin Bldg', floor: 'Basement' }
  ];

  // Default initial Administrator Account so the user can log in immediately
  var DEFAULT_USERS = [
    {
      id: 'USR-001',
      username: 'admin',
      password: 'admin123', // In production or for defense, plain/hash stored in local storage
      fullName: 'System Administrator',
      role: 'Admin', // Admin, Custodian, Faculty, Staff, Student
      department: 'Property & Supply Office',
      email: 'admin@school.edu',
      createdAt: new Date().toISOString()
    }
  ];

  // Database Service Object
  var DB = {
    load: function() {
      try {
        var raw = localStorage.getItem(STORAGE_KEY);
        if (raw) {
          var parsed = JSON.parse(raw);
          // Ensure reservations, users arrays exist
          parsed.users = parsed.users || DEFAULT_USERS;
          parsed.reservations = parsed.reservations || [];
          return parsed;
        }
      } catch (e) {
        console.warn('Failed to parse localStorage DB, initializing blank database', e);
      }
      return this.initBlankDatabase();
    },

    save: function(data) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
        return true;
      } catch (e) {
        console.error('Failed to save to localStorage', e);
        return false;
      }
    },

    // Initialize COMPLETELY BLANK DATABASE (Zero items, zero transactions, zero audits)
    initBlankDatabase: function() {
      var blank = {
        schoolProfile: JSON.parse(JSON.stringify(DEFAULT_SCHOOL_PROFILE)),
        categories: JSON.parse(JSON.stringify(DEFAULT_CATEGORIES)),
        rooms: JSON.parse(JSON.stringify(DEFAULT_ROOMS)),
        users: JSON.parse(JSON.stringify(DEFAULT_USERS)),
        items: [],          // 100% EMPTY - Ready for user's real items
        transactions: [],   // 100% EMPTY - Past and present movement logs
        reservations: [],   // 100% EMPTY - Future bookings and scheduled usage
        audits: [],         // 100% EMPTY - Physical inventory audit history
        maintenance: [],    // 100% EMPTY - Equipment repair ledger
        version: '2.0.0',
        lastUpdated: new Date().toISOString()
      };
      this.save(blank);
      return blank;
    },

    clearAllData: function() {
      return this.initBlankDatabase();
    },

    // -------------------------------------------------------------
    // USER ACCOUNTS & AUTHENTICATION
    // -------------------------------------------------------------
    getUsers: function() {
      return this.load().users || [];
    },

    getCurrentUser: function() {
      try {
        var raw = localStorage.getItem(SESSION_KEY);
        if (raw) return JSON.parse(raw);
      } catch (e) {}
      // Default fallback to first admin
      var users = this.getUsers();
      var defaultUser = users[0] || { username: 'admin', fullName: 'Administrator', role: 'Admin' };
      this.setCurrentUser(defaultUser);
      return defaultUser;
    },

    setCurrentUser: function(user) {
      localStorage.setItem(SESSION_KEY, JSON.stringify(user));
    },

    login: function(username, password) {
      var users = this.getUsers();
      var found = users.find(function(u) {
        return u.username.toLowerCase() === username.trim().toLowerCase() && u.password === password;
      });
      if (found) {
        this.setCurrentUser(found);
        return found;
      }
      return null;
    },

    logout: function() {
      localStorage.removeItem(SESSION_KEY);
    },

    saveUser: function(user) {
      var data = this.load();
      data.users = data.users || [];
      var cleanUser = user.username.trim().toLowerCase();

      var exists = false;
      for (var i = 0; i < data.users.length; i++) {
        if (data.users[i].username.toLowerCase() === cleanUser) {
          data.users[i] = Object.assign({}, data.users[i], user);
          exists = true;
          break;
        }
      }

      if (!exists) {
        user.id = user.id || ('USR-' + String(data.users.length + 1).padStart(3, '0'));
        user.createdAt = new Date().toISOString();
        data.users.push(user);
      }

      data.lastUpdated = new Date().toISOString();
      this.save(data);
      return user;
    },

    deleteUser: function(username) {
      var data = this.load();
      if (username.toLowerCase() === 'admin') {
        throw new Error('Cannot delete primary Administrator account.');
      }
      data.users = data.users.filter(function(u) {
        return u.username.toLowerCase() !== username.toLowerCase();
      });
      data.lastUpdated = new Date().toISOString();
      this.save(data);
      return true;
    },

    // -------------------------------------------------------------
    // ASSET ITEMS CRUD (Present State)
    // -------------------------------------------------------------
    getItems: function() {
      return this.load().items || [];
    },

    getItemById: function(id) {
      if (!id) return null;
      var cleanId = id.trim().toUpperCase();
      var items = this.getItems();
      for (var i = 0; i < items.length; i++) {
        if (items[i].id.toUpperCase() === cleanId) {
          return items[i];
        }
      }
      return null;
    },

    saveItem: function(item) {
      var data = this.load();
      var cleanId = item.id.trim().toUpperCase();
      item.id = cleanId;

      var exists = false;
      for (var i = 0; i < data.items.length; i++) {
        if (data.items[i].id.toUpperCase() === cleanId) {
          data.items[i] = Object.assign({}, data.items[i], item, { updatedAt: new Date().toISOString() });
          exists = true;
          break;
        }
      }
      if (!exists) {
        item.createdAt = item.createdAt || new Date().toISOString();
        data.items.unshift(item);
      }
      data.lastUpdated = new Date().toISOString();
      this.save(data);
      return item;
    },

    deleteItem: function(id) {
      var data = this.load();
      var cleanId = id.trim().toUpperCase();
      data.items = data.items.filter(function(it) {
        return it.id.toUpperCase() !== cleanId;
      });
      data.lastUpdated = new Date().toISOString();
      this.save(data);
      return true;
    },

    // -------------------------------------------------------------
    // PAST & PRESENT: BORROW & RETURN TRANSACTIONS (Movement Tracking)
    // -------------------------------------------------------------
    getTransactions: function() {
      return this.load().transactions || [];
    },

    borrowItem: function(payload) {
      var data = this.load();
      var item = null;
      for (var i = 0; i < data.items.length; i++) {
        if (data.items[i].id.toUpperCase() === payload.itemId.toUpperCase()) {
          item = data.items[i];
          data.items[i].status = 'Borrowed';
          break;
        }
      }
      if (!item) throw new Error('Item not found: ' + payload.itemId);

      var txnId = 'TXN-' + new Date().getFullYear() + '-' + String(data.transactions.length + 1).padStart(4, '0');
      var currentUser = this.getCurrentUser();

      var newTxn = {
        id: txnId,
        itemId: item.id,
        itemName: item.name,
        borrowerName: payload.borrowerName,
        borrowerRole: payload.borrowerRole || 'Faculty',
        borrowerId: payload.borrowerId || 'N/A',
        department: payload.department || 'General',
        purpose: payload.purpose || 'Official School Usage',
        borrowDate: new Date().toISOString(),
        expectedReturnDate: payload.expectedReturnDate,
        actualReturnDate: null,
        status: 'Active', // Active (Present), Returned (Past), Overdue
        issuedBy: currentUser ? currentUser.fullName : data.schoolProfile.custodianOfficer,
        remarks: payload.remarks || 'Standard equipment release'
      };

      data.transactions.unshift(newTxn);
      data.lastUpdated = new Date().toISOString();
      this.save(data);
      return newTxn;
    },

    returnItem: function(txnId, condition, returnRemarks) {
      var data = this.load();
      var txn = null;
      var currentUser = this.getCurrentUser();

      for (var i = 0; i < data.transactions.length; i++) {
        if (data.transactions[i].id === txnId) {
          txn = data.transactions[i];
          txn.actualReturnDate = new Date().toISOString();
          txn.status = 'Returned'; // Now part of PAST history
          txn.receivedBy = currentUser ? currentUser.fullName : 'Property Custodian';
          if (returnRemarks) {
            txn.remarks = (txn.remarks ? txn.remarks + ' | Return note: ' : '') + returnRemarks;
          }
          break;
        }
      }
      if (!txn) throw new Error('Transaction record not found: ' + txnId);

      // Revert item status to Available or Under Maintenance
      for (var j = 0; j < data.items.length; j++) {
        if (data.items[j].id.toUpperCase() === txn.itemId.toUpperCase()) {
          if (condition === 'Needs Repair' || condition === 'Condemned') {
            data.items[j].status = 'Under Maintenance';
          } else {
            data.items[j].status = 'Available';
          }
          if (condition) data.items[j].condition = condition;
          break;
        }
      }

      data.lastUpdated = new Date().toISOString();
      this.save(data);
      return txn;
    },

    // -------------------------------------------------------------
    // FUTURE: RESERVATIONS & SCHEDULED ASSET BOOKINGS
    // -------------------------------------------------------------
    getReservations: function() {
      return this.load().reservations || [];
    },

    createReservation: function(res) {
      var data = this.load();
      data.reservations = data.reservations || [];

      var resId = 'RSV-' + new Date().getFullYear() + '-' + String(data.reservations.length + 1).padStart(4, '0');
      var item = this.getItemById(res.itemId);
      if (!item) throw new Error('Asset not found: ' + res.itemId);

      var currentUser = this.getCurrentUser();

      var newRes = {
        id: resId,
        itemId: item.id,
        itemName: item.name,
        reservedBy: res.reservedBy,
        reservedRole: res.reservedRole || 'Faculty',
        reservedForDate: res.reservedForDate, // Future Start Date/Time
        reservedUntilDate: res.reservedUntilDate, // Future End Date/Time
        department: res.department || 'Academics',
        purpose: res.purpose || 'Scheduled Lecture / Event',
        status: 'Scheduled', // Scheduled (Future), Released (Present), Cancelled, Completed (Past)
        bookedAt: new Date().toISOString(),
        bookedBy: currentUser ? currentUser.fullName : 'Administrator'
      };

      data.reservations.unshift(newRes);
      data.lastUpdated = new Date().toISOString();
      this.save(data);
      return newRes;
    },

    cancelReservation: function(resId) {
      var data = this.load();
      data.reservations = data.reservations || [];
      for (var i = 0; i < data.reservations.length; i++) {
        if (data.reservations[i].id === resId) {
          data.reservations[i].status = 'Cancelled';
          break;
        }
      }
      data.lastUpdated = new Date().toISOString();
      this.save(data);
      return true;
    },

    // -------------------------------------------------------------
    // AUDITS & MAINTENANCE
    // -------------------------------------------------------------
    getAudits: function() {
      return this.load().audits || [];
    },

    saveAuditRecord: function(auditRecord) {
      var data = this.load();
      auditRecord.id = auditRecord.id || ('AUD-' + new Date().getFullYear() + '-' + String(data.audits.length + 1).padStart(3, '0'));
      data.audits.unshift(auditRecord);
      data.lastUpdated = new Date().toISOString();
      this.save(data);
      return auditRecord;
    },

    getMaintenance: function() {
      return this.load().maintenance || [];
    },

    saveMaintenance: function(record) {
      var data = this.load();
      record.id = record.id || ('MNT-' + new Date().getFullYear() + '-' + String(data.maintenance.length + 1).padStart(3, '0'));
      data.maintenance.unshift(record);

      for (var i = 0; i < data.items.length; i++) {
        if (data.items[i].id.toUpperCase() === record.itemId.toUpperCase()) {
          data.items[i].status = record.status === 'Resolved' ? 'Available' : 'Under Maintenance';
          break;
        }
      }

      data.lastUpdated = new Date().toISOString();
      this.save(data);
      return record;
    },

    // -------------------------------------------------------------
    // PROFILE, ROOMS, CATEGORIES
    // -------------------------------------------------------------
    getSchoolProfile: function() {
      return this.load().schoolProfile;
    },

    saveSchoolProfile: function(profile) {
      var data = this.load();
      data.schoolProfile = Object.assign({}, data.schoolProfile, profile);
      data.lastUpdated = new Date().toISOString();
      this.save(data);
      return data.schoolProfile;
    },

    getRooms: function() {
      return this.load().rooms;
    },

    saveRoom: function(room) {
      var data = this.load();
      var exists = false;
      for (var i = 0; i < data.rooms.length; i++) {
        if (data.rooms[i].id === room.id) {
          data.rooms[i] = Object.assign({}, data.rooms[i], room);
          exists = true;
          break;
        }
      }
      if (!exists) {
        room.id = room.id || ('room-' + Date.now().toString(36));
        data.rooms.push(room);
      }
      data.lastUpdated = new Date().toISOString();
      this.save(data);
      return room;
    },

    getCategories: function() {
      return this.load().categories;
    },

    // -------------------------------------------------------------
    // DATABASE EXPORT & IMPORT (JSON BACKUP / RESTORE)
    // -------------------------------------------------------------
    exportDatabaseJson: function() {
      var data = this.load();
      return JSON.stringify(data, null, 2);
    },

    importDatabaseJson: function(jsonString) {
      var parsed = JSON.parse(jsonString);
      if (!parsed.schoolProfile) {
        throw new Error('Invalid SmartTrack backup file schema.');
      }
      this.save(parsed);
      return true;
    }
  };

  window.SmartTrackDB = DB;
})(window);
