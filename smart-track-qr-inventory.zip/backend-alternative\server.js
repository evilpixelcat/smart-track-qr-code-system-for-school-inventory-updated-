/**
 * SmartTrack Backend API Server (Express.js RESTful Microservice)
 * Optional backend implementation for Capstone client-server architecture
 */
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'server_db.json');

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..')));

// Helper to load JSON database
function loadDb() {
  if (!fs.existsSync(DB_FILE)) {
    const defaultData = {
      users: [
        { id: 'USR-001', username: 'admin', password: 'admin123', fullName: 'Administrator', role: 'Admin' }
      ],
      items: [],
      transactions: [],
      reservations: [],
      audits: []
    };
    fs.writeFileSync(DB_FILE, JSON.stringify(defaultData, null, 2));
    return defaultData;
  }
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
}

function saveDb(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

// REST Endpoints
app.get('/api/items', (req, res) => {
  const db = loadDb();
  res.json({ success: true, count: db.items.length, data: db.items });
});

app.get('/api/items/:id', (req, res) => {
  const db = loadDb();
  const item = db.items.find(i => i.id.toUpperCase() === req.params.id.toUpperCase());
  if (!item) return res.status(404).json({ success: false, message: 'Item not found' });
  res.json({ success: true, data: item });
});

app.post('/api/items', (req, res) => {
  const db = loadDb();
  const newItem = req.body;
  if (!newItem.id || !newItem.name) {
    return res.status(400).json({ success: false, message: 'id and name are required' });
  }
  db.items.push(newItem);
  saveDb(db);
  res.status(201).json({ success: true, message: 'Item registered', data: newItem });
});

app.post('/api/borrow', (req, res) => {
  const db = loadDb();
  const { itemId, borrowerName, purpose, expectedReturnDate } = req.body;
  const item = db.items.find(i => i.id.toUpperCase() === itemId.toUpperCase());
  if (!item) return res.status(404).json({ success: false, message: 'Item not found' });
  
  item.status = 'Borrowed';
  const txn = {
    id: 'TXN-' + Date.now(),
    itemId,
    borrowerName,
    purpose,
    borrowDate: new Date().toISOString(),
    expectedReturnDate,
    status: 'Active'
  };
  db.transactions.push(txn);
  saveDb(db);
  res.json({ success: true, message: 'Item borrowed', transaction: txn });
});

app.listen(PORT, () => {
  console.log(`SmartTrack Server listening at http://localhost:${PORT}`);
});
