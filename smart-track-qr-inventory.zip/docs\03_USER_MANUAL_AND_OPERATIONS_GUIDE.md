# SMARTTRACK: USER MANUAL & OPERATIONS GUIDE

## 1. Quick Start (Running the System)
1. Double-click `run.bat` or open `index.html` directly in any web browser (Google Chrome, Microsoft Edge, Mozilla Firefox, or Safari).
2. No internet connection is required. No Node.js or software installation is required.

---

## 2. Navigating the Core Modules

### 2.1 Dashboard
- **Executive Statistics**: View Total School Assets, Cumulative Appraised Value, Borrowed Assets, and Units Under Maintenance at a glance.
- **Visual Distributions**: Review equipment allocation across academic categories (IT, Science, AV, Furniture) and rooms.
- **Recent Activity Feed**: Track real-time check-outs and check-ins.

### 2.2 Registering Assets & Generating QR Codes
1. Click **➕ New Asset** or **Register Asset**.
2. Input the Asset ID (auto-generated or enter existing inventory property sticker code).
3. Select Category, Assigned Room, Brand, Model, Serial Number, and Unit Cost.
4. Click **Save Asset**. The item is immediately registered and its cryptographic QR code is generated.
5. Click **🔍 QR** on any asset row to preview the high-res QR card, download it as a PNG, or print an individual label.

### 2.3 QR Code Scanning (Multi-Modal)
1. Navigate to **📷 QR Code Scanner**.
2. **Camera Scanning**: Click **📷 Start Live Camera**. Allow camera permissions in the browser. Point the camera at any physical QR asset tag.
3. **Image Upload Scanning**: Click or drag-and-drop a photo of a QR code sticker into the upload box.
4. **USB Barcode Gun**: Connect any standard plug-and-play USB 2D barcode scanner wand. Scan an asset tag anywhere on the screen—the system automatically intercepts the scan!
5. **Instant Scan Actions**: When recognized, the system emits an audio ding and displays:
   - **Check-Out / Borrow**: If the item is Available.
   - **Check-In / Return**: If the item is currently Borrowed.
   - **Full Profile**: To inspect maintenance and acquisition specs.

### 2.4 Borrowing & Return Tracking
- **Issuing Equipment**:
  1. Click **➕ Issue Equipment**.
  2. Select the available asset from the dropdown (or scan its QR code).
  3. Enter the borrower's name, role (Faculty, Student, Staff), ID number, and purpose.
  4. Specify the Expected Return Date & Time.
  5. Click **Confirm Check-Out**. The asset status updates to "Borrowed" and is color-coded in yellow.
- **Checking-In / Returning**:
  1. From the Borrow & Return Hub, click **📥 Check-In / Return** on any active transaction.
  2. Inspect the physical item and select its return condition (Good, Fair, Needs Repair, Condemned).
  3. Enter custodian inspection remarks and confirm. The asset status immediately reverts to "Available" (or "Under Maintenance" if damage is reported).

### 2.5 Physical Room Audit Mode
1. Navigate to **📍 Room Audit Mode**.
2. Select the target room (e.g., "Computer Laboratory 1").
3. Click **🚀 Begin Physical Audit**.
4. The system displays all expected items with an audit progress bar.
5. Walk through the room with your laptop or camera device and scan the physical QR tags:
   - Present items turn **GREEN** ("VERIFIED FOUND").
   - If an item belonging to another room is scanned, the system sounds an alert and flags the item as **MISPLACED**, showing its original room and giving you a one-click option to transfer it.
6. When finished, click **🏁 Complete Audit & Log Report**.

### 2.6 Export & Reporting Center
- **Official Government / School Inventory Report**:
  - Click **📄 Generate Official Report (Print / PDF)**.
  - Opens a formatted Report on the Physical Count of Property, Plant and Equipment (RPCPPE) with institutional header, grand total valuations, and signature blocks. Use Ctrl+P or the Print button to print or save directly to PDF.
- **Printable A4 QR Sticker Sheets**:
  - Click **🖨️ Print All A4 QR Asset Stickers**.
  - Renders an A4 grid of tamper-evident asset tags with cut lines ready for adhesive sticker paper.
- **CSV & Excel Export**:
  - Click **📥 Export Assets to CSV** or **📥 Export Movement History to CSV**.
  - Opens in Microsoft Excel with formatted columns.
- **System Backup & Restore**:
  - Click **💾 Download JSON Database Backup** to save a snapshot file.
  - Use **📂 Restore Database from JSON** to reload or migrate data to any other computer!
