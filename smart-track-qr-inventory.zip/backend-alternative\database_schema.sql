-- ====================================================================
-- SMARTTRACK: QR CODE SYSTEM FOR SCHOOL INVENTORY MANAGEMENT
-- Relational Database Schema & Data Definition Language (DDL)
-- Includes Accounts & Past / Present / Future Lifecycle Tracking
-- Compatible with MySQL 8.0+, MariaDB 10.5+, PostgreSQL 14+, SQLite 3
-- ====================================================================

-- 1. USER ACCOUNTS (Role-Based Access Control)
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(80) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(150),
    role ENUM('Admin', 'Custodian', 'Faculty', 'Staff', 'Student') NOT NULL DEFAULT 'Faculty',
    department VARCHAR(150),
    status ENUM('Active', 'Inactive') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Initial Administrator Account
INSERT INTO users (username, password_hash, full_name, email, role, department)
VALUES ('admin', 'admin123', 'System Administrator', 'admin@school.edu', 'Admin', 'Property & Supply Office');

-- 2. SCHOOL PROFILE
CREATE TABLE IF NOT EXISTS school_profile (
    id INT PRIMARY KEY AUTO_INCREMENT,
    school_name VARCHAR(255) NOT NULL,
    sub_title VARCHAR(255),
    campus VARCHAR(150),
    address TEXT,
    custodian_officer VARCHAR(150) NOT NULL,
    school_head VARCHAR(150) NOT NULL,
    currency VARCHAR(10) DEFAULT '₱',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. ASSET CATEGORIES
CREATE TABLE IF NOT EXISTS categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category_code VARCHAR(20) NOT NULL UNIQUE,
    category_name VARCHAR(100) NOT NULL,
    icon VARCHAR(20)
);

-- 4. LOCATIONS / ROOMS
CREATE TABLE IF NOT EXISTS locations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    room_code VARCHAR(50) NOT NULL UNIQUE,
    room_name VARCHAR(150) NOT NULL,
    building VARCHAR(100) NOT NULL,
    floor_level VARCHAR(50)
);

-- 5. ASSET INVENTORY (PRESENT STATE)
CREATE TABLE IF NOT EXISTS inventory_assets (
    id VARCHAR(50) PRIMARY KEY, -- QR Code ID (e.g., SCH-AST-001)
    item_name VARCHAR(255) NOT NULL,
    category_name VARCHAR(100) NOT NULL,
    location_name VARCHAR(150) NOT NULL,
    custodian_name VARCHAR(150),
    brand VARCHAR(100),
    model VARCHAR(150),
    serial_number VARCHAR(100) UNIQUE,
    unit_cost DECIMAL(12, 2) DEFAULT 0.00,
    status ENUM('Available', 'In Use', 'Borrowed', 'Under Maintenance', 'Disposed') NOT NULL DEFAULT 'Available',
    physical_condition ENUM('Brand New', 'Good', 'Fair', 'Needs Repair', 'Condemned') NOT NULL DEFAULT 'Good',
    purchase_date DATE,
    supplier VARCHAR(200),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 6. BORROW & RETURN LOGS (PAST & PRESENT STATE)
CREATE TABLE IF NOT EXISTS borrow_transactions (
    id VARCHAR(50) PRIMARY KEY, -- e.g. TXN-2026-0001
    asset_id VARCHAR(50) NOT NULL,
    borrower_name VARCHAR(150) NOT NULL,
    borrower_role VARCHAR(80) NOT NULL,
    borrower_id_number VARCHAR(80),
    department VARCHAR(150),
    purpose TEXT NOT NULL,
    borrow_datetime DATETIME NOT NULL,
    expected_return_datetime DATETIME NOT NULL,
    actual_return_datetime DATETIME NULL, -- NULL = PRESENT (Active), Populated = PAST (Returned)
    condition_on_return ENUM('Good', 'Fair', 'Needs Repair', 'Condemned') NULL,
    transaction_status ENUM('Active', 'Returned', 'Overdue') NOT NULL DEFAULT 'Active',
    issued_by VARCHAR(150) NOT NULL,
    received_by VARCHAR(150) NULL,
    remarks TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (asset_id) REFERENCES inventory_assets(id) ON UPDATE CASCADE
);

-- 7. FUTURE ASSET RESERVATIONS (FUTURE STATE)
CREATE TABLE IF NOT EXISTS asset_reservations (
    id VARCHAR(50) PRIMARY KEY, -- e.g. RSV-2026-0001
    asset_id VARCHAR(50) NOT NULL,
    reserved_by VARCHAR(150) NOT NULL,
    reserved_role VARCHAR(80) NOT NULL,
    department VARCHAR(150),
    purpose TEXT NOT NULL,
    reserved_for_datetime DATETIME NOT NULL, -- Scheduled future date
    reserved_until_datetime DATETIME NULL,
    reservation_status ENUM('Scheduled', 'Released', 'Cancelled', 'Completed') NOT NULL DEFAULT 'Scheduled',
    booked_by VARCHAR(150) NOT NULL,
    booked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (asset_id) REFERENCES inventory_assets(id) ON UPDATE CASCADE
);

-- 8. ROOM AUDIT SESSIONS
CREATE TABLE IF NOT EXISTS audit_sessions (
    id VARCHAR(50) PRIMARY KEY, -- e.g. AUD-2026-001
    room_name VARCHAR(150) NOT NULL,
    audit_date DATE NOT NULL,
    auditor_name VARCHAR(150) NOT NULL,
    total_expected INT NOT NULL,
    scanned_present INT NOT NULL,
    missing_count INT NOT NULL,
    audit_status ENUM('Passed', 'Discrepancy') NOT NULL DEFAULT 'Passed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX idx_asset_status ON inventory_assets(status);
CREATE INDEX idx_borrow_state ON borrow_transactions(transaction_status, actual_return_datetime);
CREATE INDEX idx_resv_future ON asset_reservations(reserved_for_datetime, reservation_status);
