/**
 * SmartTrack Export Engine
 * Exports Past, Present, and Future data:
 * - Master Assets (Present)
 * - Movement & Custody History (Past & Present)
 * - Future Reservations & Schedules (Future)
 * - User Accounts & Roles
 * - Official Government/Institutional RPCPPE Print/PDF Report
 * - Printable A4 QR Code Label Sheets
 * - Complete Portable JSON Database Backup & Restore
 */
(function(window) {
  'use strict';

  function triggerDownload(content, fileName, mimeType) {
    var blob = new Blob([content], { type: mimeType || 'text/plain;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    setTimeout(function() {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 150);
  }

  function escapeCsvCell(val) {
    if (val === null || val === undefined) return '""';
    var str = String(val).replace(/"/g, '""');
    return '"' + str + '"';
  }

  var ExportEngine = {
    // 1. Export Items to CSV (Present State)
    exportItemsToCSV: function(items) {
      items = items || window.SmartTrackDB.getItems();
      var headers = [
        'Asset ID', 'Item Name', 'Category', 'Location/Room', 
        'Custodian', 'Status', 'Condition', 'Brand', 'Model', 
        'Serial Number', 'Unit Cost', 'Purchase Date', 'Supplier', 'Notes'
      ];

      var rows = [];
      rows.push(headers.map(escapeCsvCell).join(','));

      items.forEach(function(item) {
        var row = [
          item.id,
          item.name,
          item.category,
          item.room,
          item.custodian || '',
          item.status,
          item.condition,
          item.brand || '',
          item.model || '',
          item.serialNumber || '',
          item.unitCost || 0,
          item.purchaseDate || '',
          item.supplier || '',
          item.notes || ''
        ];
        rows.push(row.map(escapeCsvCell).join(','));
      });

      var csvContent = '\uFEFF' + rows.join('\r\n');
      var dateStr = new Date().toISOString().slice(0, 10);
      triggerDownload(csvContent, 'SmartTrack_Assets_' + dateStr + '.csv', 'text/csv;charset=utf-8;');
    },

    // 2. Export Movement Transactions (Past & Present)
    exportTransactionsToCSV: function(txns) {
      txns = txns || window.SmartTrackDB.getTransactions();
      var headers = [
        'Transaction ID', 'Asset ID', 'Item Name', 'Borrower Name', 'Role',
        'Borrower ID', 'Department', 'Purpose', 'Date Borrowed', 'Expected Return',
        'Date Returned', 'Timeline State', 'Status', 'Issued By', 'Remarks'
      ];

      var rows = [];
      rows.push(headers.map(escapeCsvCell).join(','));

      txns.forEach(function(t) {
        var timelineState = t.status === 'Returned' ? 'PAST (Completed)' : 'PRESENT (Active In Use)';
        var row = [
          t.id,
          t.itemId,
          t.itemName,
          t.borrowerName,
          t.borrowerRole,
          t.borrowerId,
          t.department,
          t.purpose,
          t.borrowDate,
          t.expectedReturnDate,
          t.actualReturnDate || 'Currently Active',
          timelineState,
          t.status,
          t.issuedBy,
          t.remarks
        ];
        rows.push(row.map(escapeCsvCell).join(','));
      });

      var csvContent = '\uFEFF' + rows.join('\r\n');
      var dateStr = new Date().toISOString().slice(0, 10);
      triggerDownload(csvContent, 'SmartTrack_Movement_Logs_' + dateStr + '.csv', 'text/csv;charset=utf-8;');
    },

    // 3. Export Future Reservations to CSV (Future State)
    exportReservationsToCSV: function(reservations) {
      reservations = reservations || window.SmartTrackDB.getReservations();
      var headers = [
        'Reservation ID', 'Asset ID', 'Item Name', 'Reserved By', 'Role',
        'Department', 'Purpose', 'Reserved For Date', 'Reserved Until Date', 'Status', 'Booked At'
      ];

      var rows = [];
      rows.push(headers.map(escapeCsvCell).join(','));

      reservations.forEach(function(r) {
        var row = [
          r.id,
          r.itemId,
          r.itemName,
          r.reservedBy,
          r.reservedRole,
          r.department,
          r.purpose,
          r.reservedForDate,
          r.reservedUntilDate,
          r.status,
          r.bookedAt
        ];
        rows.push(row.map(escapeCsvCell).join(','));
      });

      var csvContent = '\uFEFF' + rows.join('\r\n');
      var dateStr = new Date().toISOString().slice(0, 10);
      triggerDownload(csvContent, 'SmartTrack_Future_Reservations_' + dateStr + '.csv', 'text/csv;charset=utf-8;');
    },

    // 4. Export Full Portable System Backup JSON (Accounts + Items + Past/Present/Future)
    exportSystemBackup: function() {
      var jsonStr = window.SmartTrackDB.exportDatabaseJson();
      var dateStr = new Date().toISOString().slice(0, 10);
      triggerDownload(jsonStr, 'SmartTrack_Full_Database_Backup_' + dateStr + '.json', 'application/json');
    },

    // 5. Generate Official RPCPPE Printable Report
    printOfficialInventoryReport: function(items, filterTitle) {
      items = items || window.SmartTrackDB.getItems();
      var profile = window.SmartTrackDB.getSchoolProfile();
      filterTitle = filterTitle || 'General School Physical Property & Equipment Inventory';

      var totalValuation = items.reduce(function(sum, it) {
        return sum + (Number(it.unitCost) || 0);
      }, 0);

      var curr = profile.currency || '₱';
      var formattedValuation = curr + ' ' + totalValuation.toLocaleString('en-US', { minimumFractionDigits: 2 });
      var reportDate = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

      var rowsHtml = items.length === 0 ? 
        `<tr><td colspan="9" style="text-align: center; padding: 24px; color: #64748b;">No assets currently registered in inventory.</td></tr>` :
        items.map(function(it, idx) {
          var cost = Number(it.unitCost) || 0;
          return `
            <tr>
              <td style="text-align: center;">${idx + 1}</td>
              <td style="font-family: monospace; font-weight: bold;">${it.id}</td>
              <td><strong>${it.name}</strong><br><small style="color: #4b5563;">${it.brand || ''} ${it.model || ''}</small></td>
              <td>${it.category}</td>
              <td>${it.room}</td>
              <td>${it.custodian || 'Unassigned'}</td>
              <td style="text-align: center;"><span class="badge ${it.status.toLowerCase().replace(/\s+/g, '-')}">${it.status}</span></td>
              <td style="text-align: center;">${it.condition}</td>
              <td style="text-align: right; font-family: monospace;">${curr} ${cost.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
            </tr>
          `;
        }).join('');

      var printWindow = window.open('', '_blank');
      if (!printWindow) {
        alert('Please allow popups to generate the official printable report.');
        return;
      }

      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Official Inventory Report - ${profile.schoolName}</title>
          <meta charset="utf-8" />
          <style>
            @page { size: landscape A4; margin: 15mm 10mm; }
            body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 11px; color: #1e293b; margin: 0; padding: 20px; }
            .header { text-align: center; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 16px; }
            .school-logo { font-size: 32px; margin-bottom: 4px; }
            .school-name { font-size: 18px; font-weight: 800; text-transform: uppercase; color: #0f172a; }
            .school-sub { font-size: 13px; color: #475569; font-weight: 600; }
            .report-title-box { background: #f1f5f9; padding: 8px 16px; border-radius: 6px; margin: 12px 0; display: flex; justify-content: space-between; align-items: center; }
            .report-title { font-size: 14px; font-weight: 700; text-transform: uppercase; }
            table { width: 100%; border-collapse: collapse; margin-top: 10px; }
            th { background: #1e293b; color: #ffffff; text-align: left; padding: 7px 6px; font-size: 10px; text-transform: uppercase; }
            td { padding: 6px; border-bottom: 1px solid #e2e8f0; vertical-align: middle; }
            tr:nth-child(even) { background-color: #f8fafc; }
            .total-row { background: #e2e8f0 !important; font-weight: 800; }
            .badge { display: inline-block; padding: 2px 6px; border-radius: 4px; font-size: 9px; font-weight: 600; }
            .badge.available { background: #dcfce7; color: #15803d; }
            .badge.borrowed { background: #fef3c7; color: #b45309; }
            .badge.in-use { background: #dbeafe; color: #1d4ed8; }
            .signatures { margin-top: 40px; display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; page-break-inside: avoid; }
            .sig-box { text-align: center; }
            .sig-line { border-top: 1px solid #1e293b; margin: 35px 20px 6px 20px; }
            .sig-name { font-weight: 700; font-size: 11px; text-transform: uppercase; }
            .sig-role { font-size: 10px; color: #64748b; }
            .actions-bar { position: fixed; top: 12px; right: 20px; background: white; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
            .btn { background: #0284c7; color: white; border: none; padding: 6px 14px; font-weight: 600; border-radius: 4px; cursor: pointer; }
            @media print { .actions-bar { display: none !important; } body { padding: 0; } }
          </style>
        </head>
        <body>
          <div class="actions-bar">
            <button class="btn" onclick="window.print()">🖨️ Print / Save to PDF</button>
          </div>
          <div class="header">
            <div class="school-logo">🏛️</div>
            <div class="school-name">${profile.schoolName}</div>
            <div class="school-sub">${profile.subTitle}</div>
            <div>${profile.address} • ${profile.campus}</div>
          </div>
          <div class="report-title-box">
            <div class="report-title">${filterTitle}</div>
            <div>Date: <strong>${reportDate}</strong> | Total Items: <strong>${items.length}</strong></div>
          </div>
          <table>
            <thead>
              <tr>
                <th style="width: 30px; text-align: center;">#</th>
                <th style="width: 100px;">Asset Tag / QR</th>
                <th>Item Description</th>
                <th>Category</th>
                <th>Room / Location</th>
                <th>Assigned Custodian</th>
                <th style="width: 80px; text-align: center;">Status</th>
                <th style="width: 70px; text-align: center;">Condition</th>
                <th style="width: 110px; text-align: right;">Unit Value</th>
              </tr>
            </thead>
            <tbody>
              ${rowsHtml}
              <tr class="total-row">
                <td colspan="8" style="text-align: right; padding-right: 12px; text-transform: uppercase;">Total Valuation:</td>
                <td style="text-align: right; font-family: monospace;">${formattedValuation}</td>
              </tr>
            </tbody>
          </table>
          <div class="signatures">
            <div class="sig-box">
              <div class="sig-role">Prepared By:</div>
              <div class="sig-line"></div>
              <div class="sig-name">${profile.custodianOfficer}</div>
              <div class="sig-role">${profile.custodianTitle}</div>
            </div>
            <div class="sig-box">
              <div class="sig-role">Audited By:</div>
              <div class="sig-line"></div>
              <div class="sig-name">Internal Property Auditor</div>
              <div class="sig-role">Property Audit Committee</div>
            </div>
            <div class="sig-box">
              <div class="sig-role">Approved By:</div>
              <div class="sig-line"></div>
              <div class="sig-name">${profile.schoolHead}</div>
              <div class="sig-role">${profile.schoolHeadTitle}</div>
            </div>
          </div>
        </body>
        </html>
      `);
      printWindow.document.close();
    },

    // 6. Print Batch QR Stickers Sheet (A4 Grid)
    printBatchQRStickers: function(items) {
      items = items || window.SmartTrackDB.getItems();
      var profile = window.SmartTrackDB.getSchoolProfile();

      if (items.length === 0) {
        alert('No assets registered in inventory yet. Add an asset first to print QR stickers.');
        return;
      }

      var stickersHtml = items.map(function(item) {
        var qrDataUrl = window.SmartTrackQR.getQRDataUrl(item.id, 200);
        return `
          <div class="sticker">
            <div class="st-hdr">
              <span class="st-ico">🏛️</span>
              <div class="st-hdr-text">
                <div class="st-school">${profile.schoolName}</div>
                <div class="st-prop">PROPERTY OF SUPPLY OFFICE</div>
              </div>
            </div>
            <div class="st-body">
              <div class="st-qr-box">
                <img src="${qrDataUrl}" alt="${item.id}" />
                <div class="st-id">${item.id}</div>
              </div>
              <div class="st-info">
                <div class="st-name">${item.name}</div>
                <div class="st-meta"><strong>Room:</strong> ${item.room}</div>
                <div class="st-meta"><strong>Category:</strong> ${item.category}</div>
                <div class="st-meta"><strong>SN:</strong> ${item.serialNumber || 'N/A'}</div>
                <div class="st-meta"><strong>Date:</strong> ${item.purchaseDate || 'N/A'}</div>
              </div>
            </div>
            <div class="st-ftr">TAMPER-EVIDENT TAG • DO NOT REMOVE</div>
          </div>
        `;
      }).join('');

      var printWindow = window.open('', '_blank');
      if (!printWindow) {
        alert('Please allow popups to open the printable sticker sheet.');
        return;
      }

      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Printable QR Code Asset Tags - SmartTrack</title>
          <meta charset="utf-8" />
          <style>
            @page { size: A4 portrait; margin: 8mm; }
            body { font-family: 'Segoe UI', Arial, sans-serif; margin: 0; padding: 10px; background: #f8fafc; }
            .toolbar { position: sticky; top: 0; background: white; padding: 10px 16px; border-radius: 8px; margin-bottom: 16px; box-shadow: 0 2px 4px rgba(0,0,0,0.08); display: flex; justify-content: space-between; align-items: center; }
            .btn-print { background: #0284c7; color: white; border: none; padding: 8px 18px; font-weight: 700; border-radius: 6px; cursor: pointer; }
            .stickers-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8mm 6mm; }
            .sticker { background: #ffffff; border: 1.5px dashed #94a3b8; border-radius: 6px; padding: 8px 10px; page-break-inside: avoid; }
            .st-hdr { display: flex; align-items: center; border-bottom: 1px solid #cbd5e1; padding-bottom: 4px; margin-bottom: 6px; }
            .st-ico { font-size: 18px; margin-right: 6px; }
            .st-school { font-size: 9px; font-weight: 800; text-transform: uppercase; color: #0f172a; }
            .st-prop { font-size: 8px; font-weight: 700; color: #dc2626; }
            .st-body { display: flex; align-items: center; gap: 10px; }
            .st-qr-box { text-align: center; flex-shrink: 0; }
            .st-qr-box img { width: 75px; height: 75px; display: block; }
            .st-id { font-family: monospace; font-size: 10px; font-weight: 800; color: #0f172a; margin-top: 2px; }
            .st-info { flex: 1; min-width: 0; }
            .st-name { font-size: 10px; font-weight: 700; color: #0f172a; margin-bottom: 4px; }
            .st-meta { font-size: 8.5px; color: #334155; line-height: 1.3; }
            .st-ftr { font-size: 7px; font-weight: 800; text-align: center; color: #64748b; border-top: 1px solid #e2e8f0; margin-top: 6px; padding-top: 3px; }
            @media print { .toolbar { display: none !important; } body { background: white; padding: 0; } }
          </style>
        </head>
        <body>
          <div class="toolbar">
            <div>🖨️ SmartTrack QR Asset Sticker Sheet (${items.length} Labels)</div>
            <button class="btn-print" onclick="window.print()">Print Labels (A4)</button>
          </div>
          <div class="stickers-grid">
            ${stickersHtml}
          </div>
        </body>
        </html>
      `);
      printWindow.document.close();
    }
  };

  window.SmartTrackExport = ExportEngine;
})(window);
