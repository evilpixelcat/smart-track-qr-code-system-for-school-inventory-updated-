# SmartTrack: QR Code System for School Inventory

[![Capstone Ready](https://img.shields.io/badge/Status-Capstone%20Ready-success.svg)](file:///index.html)
[![Architecture](https://img.shields.io/badge/Architecture-Standalone%20%2B%20Offline%20First-blue.svg)](file:///index.html)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](file:///README.md)

**SmartTrack** is an exportable, zero-dependency, automated School Inventory and Property Management System built specifically for academic institutions, supply offices, and property custodians. It pairs physical tamper-evident QR code asset tags with comprehensive movement tracking, room audits, and multi-format reporting.

---

## 🚀 Quick Launch
1. **Zero Setup Required**: Simply double-click **`run.bat`** or open **`index.html`** in any web browser (Chrome, Edge, Firefox, Safari).
2. Works 100% offline without any server, Node.js, or external database required!

---

## 📦 What Is Included in This Capstone Package

```
smart-track-inventory/
├── index.html                                 # Complete Single-Page Web Application
├── run.bat                                    # One-click Windows Launcher
├── css/
│   └── styles.css                             # Design System & Responsive Print Styles
├── js/
│   ├── app.js                                 # Main State Controller & Navigation Router
│   ├── db.js                                  # LocalStorage Repository with 25+ realistic pre-seeded assets
│   ├── qr-engine.js                           # Reed-Solomon QR Generator, Scanner & Audio Synthesizer
│   ├── export-engine.js                       # CSV, Excel, RPCPPE PDF Reports & A4 Stickers
│   └── vendor/
│       └── qrcode.js                          # Pure JavaScript Standalone QR Code Engine
├── templates/
│   └── printable_stickers_sheet.html          # High-density A4 QR Sticker Sheet Generator
├── docs/                                      # Complete Capstone Research & Defense Suite
│   ├── 01_CAPSTONE_PROJECT_MANUSCRIPT.md      # Full Chapters 1 to 5 Capstone Research Paper
│   ├── 02_DATABASE_DATA_DICTIONARY.md         # Detailed Table & Field Specifications
│   ├── 03_USER_MANUAL_AND_OPERATIONS_GUIDE.md # User & Custodian Guide
│   └── 04_CAPSTONE_DEFENSE_QA_AND_SLIDES.md   # Presentation Slides Script + 15 Panel Defense Q&A
├── backend-alternative/                       # Client-Server Architecture (Optional for panel)
│   ├── server.js                              # Express.js REST API Microservice
│   ├── database_schema.sql                    # Production-ready MySQL/PostgreSQL/SQLite DDL
│   └── package.json
└── README.md                                  # System Documentation & Guide
```

---

## 🌟 Key Features

1. **Dashboard & Executive Analytics**: Real-time asset count, cumulative appraised valuation, borrowed assets, room allocation, and category breakdown.
2. **Dynamic QR Code Generation**: Instant QR generation for every registered item with downloadable PNG and single-sticker printing.
3. **Multi-Modal Scanner**:
   - Web camera stream (WebRTC + BarcodeDetector API).
   - QR image file upload dropzone.
   - Physical USB 2D barcode scanner wand integration (HID keyboard auto-detection).
   - Interactive Quick Demo test buttons.
4. **Borrow & Return Hub (Movement Tracking)**: Issue equipment to faculty, staff, or students with due date alerts, overdue warnings, and physical return condition checks.
5. **Physical Room Audit Mode**:
   - Select a room (e.g., Computer Lab 1).
   - Scan physical tags in the room. Verified items turn green.
   - **Misplaced Item Alerts**: Triggers warnings if an asset assigned to another room is detected.
6. **Maintenance & Repair Ledger**: Log malfunctioning assets, technician assignments, repair cost estimates, and resolutions.
7. **Complete Exportability**:
   - 📥 **Export to CSV**: Formatted master assets and movement history.
   - 📊 **Excel-Ready**: Prepend UTF-8 BOM so Excel opens files without corrupted accents.
   - 📄 **Official RPCPPE Report**: Formatted institutional Physical Count Report with custodian, auditor, and principal signature lines.
   - 🖨️ **Printable A4 QR Sticker Sheets**: Multi-item sticker sheets with cut lines for physical tagging.
   - 💾 **JSON Database Backup & Restore**: Full portable system migration.

---

## 🎓 Capstone Defense & Documentation
All academic deliverables are ready in the `docs/` folder:
- **`01_CAPSTONE_PROJECT_MANUSCRIPT.md`**: Complete Chapters 1–5 research paper following standard academic formatting.
- **`04_CAPSTONE_DEFENSE_QA_AND_SLIDES.md`**: 12-slide presentation structure and answers to the 15 toughest defense questions.
