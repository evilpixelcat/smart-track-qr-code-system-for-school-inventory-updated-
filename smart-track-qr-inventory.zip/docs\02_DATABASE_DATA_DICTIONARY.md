# SMARTTRACK: DATABASE DATA DICTIONARY

## Entity Relationship Overview
The SmartTrack relational model consists of 7 primary entities organized around the central `inventory_assets` master table:
1. `school_profile`: Institutional branding, administration, and print settings.
2. `categories`: Classification hierarchy (IT, Laboratory, Furniture, AV, PE).
3. `locations`: Physical buildings, floors, and rooms.
4. `inventory_assets`: Master physical asset records with QR identifiers.
5. `borrow_transactions`: Custodial checkout and return records.
6. `audit_sessions` & `audit_scan_details`: Physical room audit verification logs.
7. `maintenance_tickets`: Equipment repair and incident ledger.

---

## Detailed Data Dictionary

### Table 1: `school_profile`
| Column Name | Data Type | Nullable | Default | Description |
| :--- | :--- | :---: | :---: | :--- |
| `id` | INT | No | AUTO_INC | Primary Key |
| `school_name` | VARCHAR(255) | No | - | Official institution name printed on stickers/reports |
| `sub_title` | VARCHAR(255) | Yes | NULL | Department or division subtitle |
| `campus` | VARCHAR(150) | Yes | NULL | Campus designation or cluster |
| `address` | TEXT | Yes | NULL | Physical mailing address |
| `custodian_officer` | VARCHAR(150) | No | - | Name of Chief Property Custodian / Supply Head |
| `custodian_title` | VARCHAR(150) | Yes | NULL | Designation of custodian |
| `school_head` | VARCHAR(150) | No | - | Name of Campus Director / Principal |
| `school_head_title` | VARCHAR(150) | Yes | NULL | Designation of school head |
| `currency` | VARCHAR(10) | Yes | '₱' | Financial currency symbol |

---

### Table 2: `inventory_assets` (Core Master Entity)
| Column Name | Data Type | Nullable | Default | Description |
| :--- | :--- | :---: | :---: | :--- |
| `id` | VARCHAR(50) | No | - | Primary Key & QR Code payload (e.g., `SCH-IT-001`) |
| `item_name` | VARCHAR(255) | No | - | Full descriptive name of asset |
| `category_id` | INT | No | - | Foreign Key -> `categories.id` |
| `location_id` | INT | No | - | Foreign Key -> `locations.id` |
| `custodian_name`| VARCHAR(150) | Yes | NULL | Name of teacher or staff member assigned |
| `brand` | VARCHAR(100) | Yes | NULL | Manufacturer / Brand (e.g., Dell, Olympus) |
| `model` | VARCHAR(150) | Yes | NULL | Model specification or hardware tier |
| `serial_number` | VARCHAR(100) | Yes | NULL | Unique OEM serial number stamped on device |
| `unit_cost` | DECIMAL(12,2)| No | 0.00 | Acquisition cost or appraised unit valuation |
| `status` | ENUM | No | 'Available'| 'Available', 'In Use', 'Borrowed', 'Under Maintenance', 'Disposed' |
| `physical_condition`| ENUM | No | 'Good' | 'Brand New', 'Good', 'Fair', 'Needs Repair', 'Condemned' |
| `purchase_date`| DATE | Yes | NULL | Date acquired or delivered to supply office |
| `supplier` | VARCHAR(200) | Yes | NULL | Vendor or supplier company name |
| `last_audit_date` | DATE | Yes | NULL | Date of most recent physical inventory count |
| `notes` | TEXT | Yes | NULL | Custodian notes or accessories included |

---

### Table 3: `borrow_transactions` (Movement Tracking)
| Column Name | Data Type | Nullable | Default | Description |
| :--- | :--- | :---: | :---: | :--- |
| `id` | VARCHAR(50) | No | - | Primary Key (e.g., `TXN-2026-001`) |
| `asset_id` | VARCHAR(50) | No | - | Foreign Key -> `inventory_assets.id` |
| `borrower_name` | VARCHAR(150) | No | - | Full name of borrower (Teacher, Student, Staff) |
| `borrower_role` | VARCHAR(80) | No | 'Faculty'| 'Faculty', 'Student', 'Administrative Staff', 'Guest' |
| `borrower_id_number`| VARCHAR(80) | Yes | NULL | Institutional ID or Employee number |
| `department` | VARCHAR(150) | Yes | NULL | College, Department, or Grade Level |
| `purpose` | TEXT | No | - | Official purpose of equipment check-out |
| `borrow_datetime`| DATETIME | No | CURRENT | Date and time equipment was released |
| `expected_return_datetime`| DATETIME | No | - | Scheduled due date and time for return |
| `actual_return_datetime`| DATETIME | Yes | NULL | Actual timestamp when checked in |
| `condition_on_return`| ENUM | Yes | NULL | 'Good', 'Fair', 'Needs Repair', 'Condemned' |
| `transaction_status`| ENUM | No | 'Active' | 'Active', 'Returned', 'Overdue' |
| `issued_by` | VARCHAR(150) | No | - | Custodian officer who authorized release |
| `remarks` | TEXT | Yes | NULL | Observations upon checkout or return inspection |

---

### Table 4: `audit_sessions` (Physical Verification)
| Column Name | Data Type | Nullable | Default | Description |
| :--- | :--- | :---: | :---: | :--- |
| `id` | VARCHAR(50) | No | - | Primary Key (e.g., `AUD-2026-01`) |
| `location_id` | INT | No | - | Foreign Key -> `locations.id` |
| `audit_date` | DATE | No | CURRENT | Date physical verification was performed |
| `auditor_name` | VARCHAR(150) | No | - | Name of lead property auditor |
| `total_expected`| INT | No | 0 | Count of assets registered to the room |
| `scanned_present`| INT | No | 0 | Count of assets physically scanned present |
| `missing_count` | INT | No | 0 | Count of unverified or missing assets |
| `misplaced_count`| INT | No | 0 | Count of assets found that belong to other rooms |
| `audit_status` | ENUM | No | 'Passed' | 'Passed', 'Incomplete', 'Discrepancy' |
| `remarks` | TEXT | Yes | NULL | Auditor summary notes |
