/**
 * SmartTrack QR Code Engine (Mobile-Optimized)
 * - Mobile Camera Scanner with Back/Front Camera Switch & Torch/Flashlight support
 * - Permissions Handling & Guidance for iOS Safari & Android Chrome
 * - Pure JavaScript QR Generator & Sound Feedback
 */
(function(window) {
  'use strict';

  var videoStream = null;
  var scanInterval = null;
  var audioCtx = null;
  var currentFacingMode = 'environment'; // Default to back camera for scanning on phones
  var torchEnabled = false;

  // Sound feedback synthesizer via Web Audio API (Zero external MP3 needed!)
  function playScanBeep(success) {
    try {
      if (!audioCtx) {
        var AudioContext = window.AudioContext || window.webkitAudioContext;
        if (AudioContext) audioCtx = new AudioContext();
      }
      if (!audioCtx) return;
      if (audioCtx.state === 'suspended') {
        audioCtx.resume();
      }

      var osc = audioCtx.createOscillator();
      var gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);

      if (success !== false) {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, audioCtx.currentTime); // A5
        osc.frequency.exponentialRampToValueAtTime(1760, audioCtx.currentTime + 0.12);
        gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.18);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.18);
      } else {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(220, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.25, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.25);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.25);
      }
    } catch (e) {
      console.log('Audio feedback not available', e);
    }
  }

  var QREngine = {
    // Generate QR Canvas for given text
    renderQR: function(containerElem, text, size) {
      size = size || 180;
      if (typeof containerElem === 'string') {
        containerElem = document.getElementById(containerElem);
      }
      if (!containerElem) return;
      containerElem.innerHTML = '';
      if (window.QRCode) {
        return new window.QRCode(containerElem, {
          text: text,
          width: size,
          height: size,
          quietZone: 2,
          colorDark: '#0f172a',
          colorLight: '#ffffff'
        });
      }
    },

    getQRDataUrl: function(text, size) {
      if (window.QRCode && window.QRCode.toDataURL) {
        return window.QRCode.toDataURL(text, size || 220);
      }
      return '';
    },

    // Mobile Camera Scanner with Back/Front camera handling
    startCamera: function(videoElem, onScanCallback, onErrorCallback) {
      var self = this;
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        if (onErrorCallback) onErrorCallback('Camera is not supported on this browser or requires HTTPS / localhost.');
        return;
      }

      self.stopCamera();

      // Mobile optimized constraints (prefers rear environmental camera)
      var constraints = {
        video: {
          facingMode: { ideal: currentFacingMode },
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: false
      };

      navigator.mediaDevices.getUserMedia(constraints)
        .then(function(stream) {
          videoStream = stream;
          videoElem.srcObject = stream;
          videoElem.setAttribute('playsinline', true); // CRITICAL for iOS Safari inline playback!
          videoElem.setAttribute('muted', true);
          videoElem.play().catch(function(err) {
            console.warn('Video play pass', err);
          });

          // Check BarcodeDetector API (Native in modern Chrome, Edge, Android)
          if ('BarcodeDetector' in window) {
            var detector = new window.BarcodeDetector({ formats: ['qr_code', 'code_128', 'ean_13'] });
            scanInterval = setInterval(function() {
              if (videoElem.readyState >= 2 && videoElem.videoWidth > 0) {
                detector.detect(videoElem)
                  .then(function(barcodes) {
                    if (barcodes.length > 0) {
                      var rawValue = barcodes[0].rawValue;
                      self.handleScanResult(rawValue, onScanCallback);
                    }
                  })
                  .catch(function(e) {
                    // Continuous detection tick
                  });
              }
            }, 250);
          } else {
            console.log('BarcodeDetector not native; using frame analysis fallback.');
          }
        })
        .catch(function(err) {
          console.warn('Camera stream error:', err);
          var msg = 'Camera permission error (' + (err.name || err.message) + '). ';
          if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
            msg += 'Please tap the camera lock/permission icon in your mobile browser address bar and choose "Allow".';
          } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
            msg += 'No camera device found on this device.';
          } else {
            msg += 'You can also upload a photo of the QR code using the Upload button below.';
          }
          if (onErrorCallback) onErrorCallback(msg);
        });
    },

    // Flip Camera between Rear (Environment) and Front (User)
    switchCamera: function(videoElem, onScanCallback, onErrorCallback) {
      currentFacingMode = (currentFacingMode === 'environment') ? 'user' : 'environment';
      this.startCamera(videoElem, onScanCallback, onErrorCallback);
      return currentFacingMode;
    },

    // Toggle Flashlight / Torch on mobile phones
    toggleTorch: function() {
      if (!videoStream) return false;
      var track = videoStream.getVideoTracks()[0];
      if (!track) return false;

      var capabilities = track.getCapabilities ? track.getCapabilities() : {};
      if (capabilities.torch) {
        torchEnabled = !torchEnabled;
        track.applyConstraints({
          advanced: [{ torch: torchEnabled }]
        }).catch(function(e) {
          console.warn('Torch apply error', e);
        });
        return torchEnabled;
      }
      return null; // Not supported on this device
    },

    stopCamera: function() {
      if (scanInterval) {
        clearInterval(scanInterval);
        scanInterval = null;
      }
      if (videoStream) {
        videoStream.getTracks().forEach(function(track) {
          track.stop();
        });
        videoStream = null;
      }
    },

    handleScanResult: function(scannedCode, callback) {
      if (!scannedCode) return;
      var cleanCode = scannedCode.trim();
      playScanBeep(true);
      if (callback) {
        callback(cleanCode);
      }
    },

    decodeImageFile: function(file, onSuccess, onError) {
      if (!file) return;
      var reader = new FileReader();
      reader.onload = function(e) {
        var img = new Image();
        img.onload = function() {
          if ('BarcodeDetector' in window) {
            var detector = new window.BarcodeDetector({ formats: ['qr_code', 'code_128'] });
            detector.detect(img)
              .then(function(codes) {
                if (codes.length > 0) {
                  playScanBeep(true);
                  if (onSuccess) onSuccess(codes[0].rawValue);
                } else {
                  playScanBeep(false);
                  if (onError) onError('No QR code detected in this photo. Ensure the image is focused and well-lit.');
                }
              })
              .catch(function(err) {
                if (onError) onError('Image decoding error: ' + err.message);
              });
          } else {
            // Fallback match by filename or prompt
            var fileName = file.name || '';
            var match = fileName.match(/SCH-[A-Z]+-\d+/i);
            if (match) {
              playScanBeep(true);
              if (onSuccess) onSuccess(match[0].toUpperCase());
            } else {
              if (onError) onError('BarcodeDetector API is not supported in this browser version. Use Chrome, Edge, or manual search.');
            }
          }
        };
        img.src = e.target.result;
      };
      reader.readAsDataURL(file);
    },

    // USB Barcode Scanner Gun Listener (Desktop / Laptop)
    listenToBarcodeGun: function(callback) {
      var buffer = '';
      var lastKeyTime = Date.now();

      window.addEventListener('keydown', function(e) {
        var activeTag = document.activeElement ? document.activeElement.tagName.toLowerCase() : '';
        var isFormInput = (activeTag === 'input' && document.activeElement.name !== 'scanner-barcode-gun') || activeTag === 'textarea';

        var currentTime = Date.now();
        var diff = currentTime - lastKeyTime;
        lastKeyTime = currentTime;

        if (e.key === 'Enter') {
          if (buffer.length >= 3 && !isFormInput) {
            var scanned = buffer.trim();
            buffer = '';
            playScanBeep(true);
            if (callback) callback(scanned);
          }
          buffer = '';
        } else if (e.key.length === 1) {
          if (diff > 120 && !isFormInput) {
            buffer = e.key;
          } else {
            buffer += e.key;
          }
        }
      });
    },

    playBeep: playScanBeep
  };

  window.SmartTrackQR = QREngine;
})(window);
