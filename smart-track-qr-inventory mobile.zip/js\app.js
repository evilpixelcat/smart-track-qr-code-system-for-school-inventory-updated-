/**
 * SmartTrack Main Application Controller (Fully Operable & Real-Time Synchronized)
 * Handles Accounts, Past/Present/Future Timeline, Room Audits, Mobile Scanner & Real-Time State
 */
(function(window) {
  'use strict';

  var currentView = 'dashboard';
  var currentTimelineFilter = 'all'; // all, past, present, future
  var activeAuditState = null;

  // Sound Feedback Helper
  function playBeep(success) {
    if (window.SmartTrackQR && window.SmartTrackQR.playBeep) {
      window.SmartTrackQR.playBeep(success);
    }
  }

  // Toast Notification System
  function showToast(message, type) {
    type = type || 'info';
    var container = document.getElementById('toast-container');
    if (!container) return;

    var toast = document.createElement('div');
    toast.className = 'toast ' + type;
    var icon = type === 'success' ? '✅' : (type === 'error' ? '❌' : 'ℹ️');
    toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(function() {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s';
      setTimeout(function() {
        if (toast.parentNode) toast.parentNode.removeChild(toast);
      }, 300);
    }, 3500);
  }

  // Modal Controls
  function openModal(id) {
    var modal = document.getElementById(id);
    if (modal) modal.classList.add('active');

    if (id === 'modal-phone-connect') {
      var qrBox = document.getElementById('phone-connect-qr');
      if (qrBox && window.SmartTrackQR) {
        var host = (window.location.hostname && window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1') ? window.location.host : '192.168.1.200:8080';
        var url = 'http://' + host + '/mobile.html';
        window.SmartTrackQR.renderQR(qrBox, url, 180);
      }
    }
  }

  function closeModal(id) {
    var modal = document.getElementById(id);
    if (modal) modal.classList.remove('active');
  }

  window.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal-overlay')) {
      e.target.classList.remove('active');
      if (e.target.id === 'modal-scanner') {
        window.SmartTrackQR.stopCamera();
      }
    }
  });

  // Navigation Controller (Desktop & Mobile Sync)
  function navigateTo(viewId) {
    currentView = viewId;

    // Desktop sidebar links
    document.querySelectorAll('.nav-link').forEach(function(link) {
      if (link.getAttribute('data-view') === viewId) link.classList.add('active');
      else link.classList.remove('active');
    });

    // Mobile bottom navigation bar items
    document.querySelectorAll('.mobile-nav-item').forEach(function(item) {
      if (item.getAttribute('data-view') === viewId) item.classList.add('active');
      else item.classList.remove('active');
    });

    // Content view sections
    document.querySelectorAll('.view-section').forEach(function(sec) {
      sec.classList.remove('active');
    });

    var targetSec = document.getElementById('view-' + viewId);
    if (targetSec) targetSec.classList.add('active');

    // Turn off camera stream when switching away from scanner
    if (viewId !== 'scanner') {
      window.SmartTrackQR.stopCamera();
      var btnCam = document.getElementById('btn-toggle-camera');
      if (btnCam) btnCam.innerHTML = '📷 Start Camera';
    }

    // Real-time render target view
    refreshAllViews();
  }

  function refreshAllViews() {
    renderDashboard();
    renderInventoryTable();
    renderTimelineView();
    renderBorrowView();
    initAuditView();
    renderUsersView();
    renderSettingsView();
    updateCurrentUserDisplay();
  }

  function formatCurrency(amount) {
    var profile = window.SmartTrackDB.getSchoolProfile();
    var curr = profile.currency || '₱';
    var num = Number(amount) || 0;
    return curr + ' ' + num.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  // Calculate Overdue status and elapsed time
  function getOverdueDetails(expectedReturnIso) {
    if (!expectedReturnIso) return { isOverdue: false, text: '' };
    var now = new Date();
    var due = new Date(expectedReturnIso);
    var diffMs = now - due;
    if (diffMs <= 0) return { isOverdue: false, text: '' };

    var diffMins = Math.floor(diffMs / (1000 * 60));
    var diffHours = Math.floor(diffMins / 60);
    var diffDays = Math.floor(diffHours / 24);

    var text = '';
    if (diffDays > 0) text = `Overdue by ${diffDays} day${diffDays > 1 ? 's' : ''}`;
    else if (diffHours > 0) text = `Overdue by ${diffHours} hr${diffHours > 1 ? 's' : ''}`;
    else text = `Overdue by ${diffMins} min${diffMins > 1 ? 's' : ''}`;

    return { isOverdue: true, text: text };
  }

  // ------------------------------------------------------------------
  // 1. DASHBOARD VIEW (Real-Time Accurate)
  // ------------------------------------------------------------------
  function renderDashboard() {
    var items = window.SmartTrackDB.getItems();
    var txns = window.SmartTrackDB.getTransactions();
    var reservations = window.SmartTrackDB.getReservations();

    var totalCount = items.length;
    var totalValuation = items.reduce(function(sum, it) {
      return sum + (Number(it.unitCost) || 0);
    }, 0);

    var borrowedCount = items.filter(function(i) { return i.status === 'Borrowed'; }).length;
    var activeReservations = reservations.filter(function(r) { return r.status === 'Scheduled'; }).length;

    var elTotal = document.getElementById('dash-total-items');
    var elVal = document.getElementById('dash-total-value');
    var elBorrowed = document.getElementById('dash-borrowed-items');
    var elFuture = document.getElementById('dash-future-reservations');

    if (elTotal) elTotal.innerText = totalCount;
    if (elVal) elVal.innerText = formatCurrency(totalValuation);
    if (elBorrowed) elBorrowed.innerText = borrowedCount;
    if (elFuture) elFuture.innerText = activeReservations;

    // Category distribution bars
    var catContainer = document.getElementById('dash-category-bars');
    if (catContainer) {
      if (totalCount === 0) {
        catContainer.innerHTML = `
          <div class="empty-state" style="padding: 24px 10px;">
            <div class="empty-icon">📦</div>
            <div class="empty-title">Database is Blank & Empty</div>
            <div class="empty-desc">No assets registered yet. Click below to add your school's physical property.</div>
            <button class="btn btn-sm btn-primary" onclick="window.SmartTrackApp.openAddItemModal()">➕ Register First Asset</button>
          </div>
        `;
      } else {
        var catCounts = {};
        items.forEach(function(it) {
          catCounts[it.category] = (catCounts[it.category] || 0) + 1;
        });
        catContainer.innerHTML = Object.keys(catCounts).map(function(cat) {
          var count = catCounts[cat];
          var pct = Math.round((count / (totalCount || 1)) * 100);
          return `
            <div style="margin-bottom: 12px;">
              <div style="display: flex; justify-content: space-between; font-size: 12px; font-weight: 600; margin-bottom: 4px;">
                <span>${cat}</span>
                <span>${count} items (${pct}%)</span>
              </div>
              <div style="height: 8px; background: #e2e8f0; border-radius: 4px; overflow: hidden;">
                <div style="width: ${pct}%; height: 100%; background: #0284c7; border-radius: 4px;"></div>
              </div>
            </div>
          `;
        }).join('');
      }
    }

    // Recent activity list
    var recentContainer = document.getElementById('dash-recent-activity');
    if (recentContainer) {
      var recentTxns = txns.slice(0, 5);
      if (recentTxns.length === 0) {
        recentContainer.innerHTML = `
          <div class="empty-state" style="padding: 24px 10px;">
            <div style="font-size: 28px; margin-bottom: 8px;">⏳</div>
            <div style="font-size: 13px; color: #64748b;">No movement activity recorded yet. Check out or return an asset to see real-time updates.</div>
          </div>
        `;
      } else {
        recentContainer.innerHTML = recentTxns.map(function(t) {
          var isRet = t.status === 'Returned';
          var dateStr = new Date(t.borrowDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
          return `
            <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-size: 12.5px;">
              <div>
                <strong>${t.borrowerName}</strong> (${t.borrowerRole})
                <div style="color: #64748b; font-size: 11.5px;">${t.itemName} (${t.itemId})</div>
              </div>
              <div style="text-align: right;">
                <span class="badge ${isRet ? 'badge-returned' : 'badge-borrowed'}">${isRet ? 'Returned' : 'In Custody'}</span>
                <div style="font-size: 10.5px; color: #94a3b8; margin-top: 2px;">${dateStr}</div>
              </div>
            </div>
          `;
        }).join('');
      }
    }
  }

  // ------------------------------------------------------------------
  // 2. INVENTORY MASTER LIST (Real-Time Search & Filters)
  // ------------------------------------------------------------------
  function renderInventoryTable() {
    var items = window.SmartTrackDB.getItems();
    var search = (document.getElementById('inv-search-input') ? document.getElementById('inv-search-input').value.toLowerCase().trim() : '');
    var catFilter = (document.getElementById('inv-filter-cat') ? document.getElementById('inv-filter-cat').value : '');
    var roomFilter = (document.getElementById('inv-filter-room') ? document.getElementById('inv-filter-room').value : '');
    var statusFilter = (document.getElementById('inv-filter-status') ? document.getElementById('inv-filter-status').value : '');

    var filtered = items.filter(function(it) {
      var matchesSearch = !search || 
        it.id.toLowerCase().includes(search) || 
        it.name.toLowerCase().includes(search) || 
        (it.brand && it.brand.toLowerCase().includes(search)) ||
        (it.serialNumber && it.serialNumber.toLowerCase().includes(search)) ||
        (it.custodian && it.custodian.toLowerCase().includes(search));

      var matchesCat = !catFilter || it.category === catFilter;
      var matchesRoom = !roomFilter || it.room === roomFilter;
      var matchesStatus = !statusFilter || it.status === statusFilter;

      return matchesSearch && matchesCat && matchesRoom && matchesStatus;
    });

    var tbody = document.getElementById('inventory-table-body');
    var emptyBox = document.getElementById('inventory-empty-state');
    var tableWrapper = document.getElementById('inventory-table-wrapper');

    if (!tbody) return;

    if (items.length === 0) {
      if (emptyBox) emptyBox.style.display = 'block';
      if (tableWrapper) tableWrapper.style.display = 'none';
      var countElem = document.getElementById('inv-item-count');
      if (countElem) countElem.innerText = '0 items';
      return;
    }

    if (emptyBox) emptyBox.style.display = 'none';
    if (tableWrapper) tableWrapper.style.display = 'block';

    if (filtered.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; padding: 24px; color: #64748b;">No assets match your search filters.</td></tr>`;
      return;
    }

    tbody.innerHTML = filtered.map(function(it) {
      var statusClass = 'badge-' + it.status.toLowerCase().replace(/\s+/g, '-');
      return `
        <tr>
          <td>
            <div style="font-family: monospace; font-weight: 700; color: #0284c7; cursor: pointer;" onclick="window.SmartTrackApp.openItemDetails('${it.id}')" title="Click to view QR & Details">
              ${it.id}
            </div>
          </td>
          <td>
            <strong>${it.name}</strong>
            <div style="font-size: 11px; color: #64748b;">${it.brand || ''} ${it.model || ''}</div>
          </td>
          <td>${it.category}</td>
          <td>📍 ${it.room}</td>
          <td>${it.custodian || 'Unassigned'}</td>
          <td><span class="badge ${statusClass}">${it.status}</span></td>
          <td><span class="badge badge-available">${it.condition}</span></td>
          <td>
            <div style="display: flex; gap: 6px;">
              <button class="btn btn-sm btn-secondary" onclick="window.SmartTrackApp.openItemDetails('${it.id}')" title="View QR Tag">🔍 QR</button>
              <button class="btn btn-sm btn-secondary" onclick="window.SmartTrackApp.openEditItemModal('${it.id}')" title="Edit Item">✏️</button>
              <button class="btn btn-sm btn-secondary" onclick="window.SmartTrackApp.deleteItemConfirm('${it.id}')" style="color: #dc2626;" title="Delete Item">🗑️</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');

    var countElem = document.getElementById('inv-item-count');
    if (countElem) countElem.innerText = `${filtered.length} of ${items.length} items`;
  }

  // ------------------------------------------------------------------
  // 3. TIMELINE HUB: PAST, PRESENT & FUTURE TRACKING
  // ------------------------------------------------------------------
  function setTimelineFilter(filter) {
    currentTimelineFilter = filter;
    document.querySelectorAll('.timeline-tab').forEach(function(tab) {
      if (tab.getAttribute('data-filter') === filter) tab.classList.add('active');
      else tab.classList.remove('active');
    });
    renderTimelineView();
  }

  function renderTimelineView() {
    var items = window.SmartTrackDB.getItems();
    var txns = window.SmartTrackDB.getTransactions();
    var reservations = window.SmartTrackDB.getReservations();

    var pastRecords = txns.filter(function(t) { return t.status === 'Returned'; });
    var presentRecords = txns.filter(function(t) { return t.status === 'Active'; });
    var futureRecords = reservations.filter(function(r) { return r.status === 'Scheduled'; });

    var cPast = document.getElementById('count-timeline-past');
    var cPresent = document.getElementById('count-timeline-present');
    var cFuture = document.getElementById('count-timeline-future');
    if (cPast) cPast.innerText = pastRecords.length;
    if (cPresent) cPresent.innerText = presentRecords.length;
    if (cFuture) cFuture.innerText = futureRecords.length;

    var container = document.getElementById('timeline-records-container');
    if (!container) return;

    var html = '';

    // FUTURE
    if (currentTimelineFilter === 'all' || currentTimelineFilter === 'future') {
      html += `<div style="margin-bottom: 20px;"><h4 style="font-size: 13px; font-weight: 700; color: #7c3aed; text-transform: uppercase; margin-bottom: 8px;">📅 Future Schedules & Reservations (${futureRecords.length})</h4>`;
      if (futureRecords.length === 0) {
        html += `<div style="background: #faf5ff; border: 1px dashed #d8b4fe; padding: 14px; border-radius: 8px; font-size: 12.5px; color: #6b21a8;">No future asset reservations booked. Click "Reserve Asset" to book equipment for an upcoming date.</div>`;
      } else {
        html += futureRecords.map(function(r) {
          var dateFor = new Date(r.reservedForDate).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
          return `
            <div style="background: white; border: 1px solid #e9d5ff; border-left: 4px solid #8b5cf6; padding: 12px 16px; border-radius: 8px; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
              <div>
                <span class="badge badge-scheduled">FUTURE RESERVATION</span>
                <strong style="font-size: 13.5px; color: #0f172a; margin-left: 6px;">${r.itemName}</strong> (${r.itemId})
                <div style="font-size: 12px; color: #4b5563; margin-top: 3px;">Reserved for: <strong>${r.reservedBy}</strong> (${r.reservedRole}) • Dept: ${r.department}</div>
                <div style="font-size: 11.5px; color: #6b21a8; font-weight: 600; margin-top: 2px;">⏰ Scheduled: ${dateFor} (Purpose: ${r.purpose})</div>
              </div>
              <div style="display: flex; gap: 6px;">
                <button class="btn btn-sm btn-primary" onclick="window.SmartTrackApp.releaseReservationNow('${r.id}')" title="Release equipment directly for use now">🚀 Check-Out Now</button>
                <button class="btn btn-sm btn-secondary" onclick="window.SmartTrackApp.cancelReservationConfirm('${r.id}')" style="color: #dc2626;">Cancel</button>
              </div>
            </div>
          `;
        }).join('');
      }
      html += `</div>`;
    }

    // PRESENT
    if (currentTimelineFilter === 'all' || currentTimelineFilter === 'present') {
      html += `<div style="margin-bottom: 20px;"><h4 style="font-size: 13px; font-weight: 700; color: #d97706; text-transform: uppercase; margin-bottom: 8px;">🟢 Present: Currently In-Use & Borrowed (${presentRecords.length})</h4>`;
      if (presentRecords.length === 0) {
        html += `<div style="background: #fffbeb; border: 1px dashed #fcd34d; padding: 14px; border-radius: 8px; font-size: 12.5px; color: #92400e;">No equipment is currently checked out. All registered assets are present in their rooms.</div>`;
      } else {
        html += presentRecords.map(function(p) {
          var bDate = new Date(p.borrowDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
          var expDate = p.expectedReturnDate ? new Date(p.expectedReturnDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'N/A';
          var overdue = getOverdueDetails(p.expectedReturnDate);

          return `
            <div style="background: white; border: 1px solid #fed7aa; border-left: 4px solid #f59e0b; padding: 12px 16px; border-radius: 8px; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
              <div>
                <span class="badge ${overdue.isOverdue ? 'badge-under-maintenance' : 'badge-borrowed'}">${overdue.isOverdue ? '⚠️ ' + overdue.text.toUpperCase() : 'CURRENTLY BORROWED'}</span>
                <strong style="font-size: 13.5px; color: #0f172a; margin-left: 6px;">${p.itemName}</strong> (${p.itemId})
                <div style="font-size: 12px; color: #4b5563; margin-top: 3px;">In Custody of: <strong>${p.borrowerName}</strong> (${p.borrowerRole}) • Dept: ${p.department}</div>
                <div style="font-size: 11.5px; color: #78350f; margin-top: 2px;">Issued on: ${bDate} | Expected Return: <strong>${expDate}</strong></div>
              </div>
              <div>
                <button class="btn btn-sm btn-success" onclick="window.SmartTrackApp.openReturnModal('${p.id}')">📥 Check-In / Return</button>
              </div>
            </div>
          `;
        }).join('');
      }
      html += `</div>`;
    }

    // PAST
    if (currentTimelineFilter === 'all' || currentTimelineFilter === 'past') {
      html += `<div><h4 style="font-size: 13px; font-weight: 700; color: #475569; text-transform: uppercase; margin-bottom: 8px;">⏳ Past: Historical Equipment Usage Log (${pastRecords.length})</h4>`;
      if (pastRecords.length === 0) {
        html += `<div style="background: #f8fafc; border: 1px dashed #cbd5e1; padding: 14px; border-radius: 8px; font-size: 12.5px; color: #64748b;">No completed transactions in history yet. As equipment is returned, full history logs appear here.</div>`;
      } else {
        html += pastRecords.map(function(h) {
          var retDate = h.actualReturnDate ? new Date(h.actualReturnDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'Returned';
          return `
            <div style="background: white; border: 1px solid #e2e8f0; border-left: 4px solid #64748b; padding: 12px 16px; border-radius: 8px; margin-bottom: 8px; font-size: 12.5px;">
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; flex-wrap: wrap;">
                <div><span class="badge badge-returned">PAST TRANSACTION</span> <strong>${h.itemName}</strong> (${h.itemId})</div>
                <div style="font-size: 11px; color: #64748b;">Returned: ${retDate}</div>
              </div>
              <div style="color: #4b5563;">Borrowed by: <strong>${h.borrowerName}</strong> (${h.borrowerRole}) • Purpose: ${h.purpose} • Handled By: ${h.issuedBy}</div>
              ${h.remarks ? `<div style="font-size: 11px; color: #0284c7; margin-top: 3px;">📝 Condition Note: ${h.remarks}</div>` : ''}
            </div>
          `;
        }).join('');
      }
      html += `</div>`;
    }

    container.innerHTML = html;
  }

  // ------------------------------------------------------------------
  // 4. USER ACCOUNTS & AUTHENTICATION
  // ------------------------------------------------------------------
  function renderUsersView() {
    var users = window.SmartTrackDB.getUsers();
    var curUser = window.SmartTrackDB.getCurrentUser();
    var tbody = document.getElementById('users-table-body');
    if (!tbody) return;

    tbody.innerHTML = users.map(function(u) {
      var isCurrent = curUser && curUser.username.toLowerCase() === u.username.toLowerCase();
      return `
        <tr style="${isCurrent ? 'background: #f0f9ff;' : ''}">
          <td>
            <strong style="color: #0284c7;">${u.username}</strong>
            ${isCurrent ? '<span style="font-size: 10px; color: #15803d; font-weight: 700; margin-left: 4px;">(ACTIVE)</span>' : ''}
          </td>
          <td><strong>${u.fullName}</strong></td>
          <td><span class="user-role-pill">${u.role}</span></td>
          <td>${u.department || 'General'}</td>
          <td>${u.email || 'N/A'}</td>
          <td>
            <div style="display: flex; gap: 6px;">
              ${!isCurrent ? `<button class="btn btn-sm btn-primary" onclick="window.SmartTrackApp.switchActiveUser('${u.username}')">Switch</button>` : '<span style="font-size: 11px; color: #15803d;">Current User</span>'}
              ${u.username !== 'admin' && !isCurrent ? `<button class="btn btn-sm btn-secondary" onclick="window.SmartTrackApp.deleteUserConfirm('${u.username}')" style="color: #dc2626;">Delete</button>` : ''}
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  function switchActiveUser(username) {
    var users = window.SmartTrackDB.getUsers();
    var found = users.find(function(u) { return u.username.toLowerCase() === username.toLowerCase(); });
    if (found) {
      window.SmartTrackDB.setCurrentUser(found);
      updateCurrentUserDisplay();
      showToast(`Switched active session to: ${found.fullName} (${found.role})`, 'success');
      renderUsersView();
    }
  }

  function updateCurrentUserDisplay() {
    var cur = window.SmartTrackDB.getCurrentUser();
    var nameElem = document.getElementById('header-user-name');
    var roleElem = document.getElementById('header-user-role');
    if (nameElem) nameElem.innerText = cur.fullName || cur.username;
    if (roleElem) roleElem.innerText = cur.role;
  }

  function openRegisterUserModal() {
    document.getElementById('form-user-modal').reset();
    openModal('modal-add-user');
  }

  function saveUserForm(e) {
    if (e) e.preventDefault();
    var username = document.getElementById('user-modal-username').value.trim();
    var fullName = document.getElementById('user-modal-name').value.trim();
    var password = document.getElementById('user-modal-password').value;
    var role = document.getElementById('user-modal-role').value;
    var department = document.getElementById('user-modal-dept').value.trim();
    var email = document.getElementById('user-modal-email').value.trim();

    if (!username || !fullName || !password) {
      showToast('Username, Full Name, and Password are required.', 'error');
      return;
    }

    window.SmartTrackDB.saveUser({
      username: username,
      fullName: fullName,
      password: password,
      role: role,
      department: department,
      email: email
    });

    closeModal('modal-add-user');
    showToast(`Account created for ${fullName} (${role})!`, 'success');
    renderUsersView();
  }

  function deleteUserConfirm(username) {
    if (confirm('Delete user account ' + username + '?')) {
      try {
        window.SmartTrackDB.deleteUser(username);
        showToast('Account removed.', 'info');
        renderUsersView();
      } catch (err) {
        showToast(err.message, 'error');
      }
    }
  }

  // ------------------------------------------------------------------
  // 5. MOBILE CAMERA SCANNER & MANUAL LOOKUP CONTROLLER
  // ------------------------------------------------------------------
  function toggleCameraScanner() {
    var video = document.getElementById('scanner-video');
    var btn = document.getElementById('btn-toggle-camera');
    var statusText = document.getElementById('scanner-status-text');

    if (btn.innerText.includes('Stop')) {
      window.SmartTrackQR.stopCamera();
      btn.innerHTML = '📷 Start Camera';
      btn.className = 'btn btn-primary';
      if (statusText) statusText.innerText = 'Camera inactive. Tap "Start Camera" to scan with your phone camera.';
    } else {
      if (statusText) statusText.innerText = 'Requesting camera permissions...';
      window.SmartTrackQR.startCamera(
        video,
        function onScan(scannedCode) {
          handleScannedItemCode(scannedCode);
        },
        function onError(err) {
          if (statusText) statusText.innerText = err;
          showToast(err, 'error');
        }
      );
      btn.innerHTML = '⏹️ Stop Camera';
      btn.className = 'btn btn-danger';
      if (statusText) statusText.innerText = 'Scanning... Align the QR asset tag inside the frame.';
    }
  }

  function flipCamera() {
    var video = document.getElementById('scanner-video');
    var mode = window.SmartTrackQR.switchCamera(
      video,
      function onScan(scannedCode) { handleScannedItemCode(scannedCode); },
      function onError(err) { showToast(err, 'error'); }
    );
    showToast('Switched to ' + (mode === 'environment' ? 'Back' : 'Front') + ' camera', 'info');
  }

  function toggleTorch() {
    var state = window.SmartTrackQR.toggleTorch();
    if (state === null) {
      showToast('Flashlight/Torch is not supported on this device camera.', 'info');
    } else {
      showToast('Flashlight ' + (state ? 'ON' : 'OFF'), 'info');
    }
  }

  // Manual Scan Input (Essential for testing on laptop or typing an asset tag)
  function handleManualScanLookup() {
    var input = document.getElementById('scanner-manual-input');
    if (!input) return;
    var val = input.value.trim();
    if (!val) {
      showToast('Please type an Asset ID to test scan.', 'error');
      return;
    }
    input.value = '';
    handleScannedItemCode(val);
  }

  function handleScannedItemCode(code) {
    code = code.trim().toUpperCase();
    var item = window.SmartTrackDB.getItemById(code);

    // If currently inside Room Audit mode, route to room audit handler!
    if (activeAuditState && currentView === 'audit') {
      handleAuditItemScan(code);
      return;
    }

    if (!item) {
      playBeep(false);
      showToast('Scanned tag [' + code + '] is not registered in your school database.', 'error');
      return;
    }

    playBeep(true);

    // Populate recognized scan result card
    var card = document.getElementById('scan-result-card');
    if (card) card.style.display = 'block';

    document.getElementById('scan-res-id').innerText = item.id;
    document.getElementById('scan-res-name').innerText = item.name;
    document.getElementById('scan-res-room').innerText = item.room;
    document.getElementById('scan-res-status').innerHTML = `<span class="badge badge-${item.status.toLowerCase().replace(/\s+/g, '-')}">${item.status}</span>`;
    document.getElementById('scan-res-custodian').innerText = item.custodian || 'Unassigned';

    var btnActBorrow = document.getElementById('scan-act-borrow');
    var btnActReturn = document.getElementById('scan-act-return');

    if (item.status === 'Available') {
      btnActBorrow.style.display = 'inline-flex';
      btnActReturn.style.display = 'none';
      btnActBorrow.onclick = function() { openBorrowModal(item.id); };
    } else if (item.status === 'Borrowed') {
      btnActBorrow.style.display = 'none';
      btnActReturn.style.display = 'inline-flex';
      btnActReturn.onclick = function() { openReturnModalByItemId(item.id); };
    } else {
      btnActBorrow.style.display = 'none';
      btnActReturn.style.display = 'none';
    }

    showToast('Asset recognized: ' + item.name, 'success');
  }

  // ------------------------------------------------------------------
  // 6. FUTURE ASSET RESERVATION MODULE
  // ------------------------------------------------------------------
  function openReservationModal(itemId) {
    var items = window.SmartTrackDB.getItems();
    if (items.length === 0) {
      showToast('Please register an asset first before making future reservations.', 'info');
      return;
    }

    document.getElementById('form-reservation-modal').reset();
    var select = document.getElementById('res-modal-item');
    select.innerHTML = items.map(function(i) {
      return `<option value="${i.id}" ${itemId === i.id ? 'selected' : ''}>[${i.id}] ${i.name} (${i.room})</option>`;
    }).join('');

    var tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(9, 0, 0, 0);
    document.getElementById('res-modal-date-for').value = tomorrow.toISOString().slice(0, 16);

    openModal('modal-create-reservation');
  }

  function saveReservationForm(e) {
    if (e) e.preventDefault();
    var itemId = document.getElementById('res-modal-item').value;
    var name = document.getElementById('res-modal-name').value.trim();
    var dateFor = document.getElementById('res-modal-date-for').value;
    var purpose = document.getElementById('res-modal-purpose').value.trim();

    if (!itemId || !name || !dateFor) {
      showToast('Asset, Reserved By, and Scheduled Date are required.', 'error');
      return;
    }

    try {
      window.SmartTrackDB.createReservation({
        itemId: itemId,
        reservedBy: name,
        reservedRole: document.getElementById('res-modal-role').value,
        department: document.getElementById('res-modal-dept').value.trim(),
        purpose: purpose || 'Academic Class Demonstration',
        reservedForDate: dateFor
      });

      closeModal('modal-create-reservation');
      showToast('Future asset reservation booked successfully!', 'success');
      renderTimelineView();
      renderDashboard();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  // Convert a future scheduled reservation directly into active checkout right now
  function releaseReservationNow(resId) {
    var reservations = window.SmartTrackDB.getReservations();
    var res = reservations.find(function(r) { return r.id === resId; });
    if (!res) return;

    var item = window.SmartTrackDB.getItemById(res.itemId);
    if (!item) {
      showToast('Asset no longer exists.', 'error');
      return;
    }

    if (item.status === 'Borrowed') {
      showToast('Asset is currently in use by another borrower.', 'error');
      return;
    }

    try {
      // Mark reservation completed
      res.status = 'Completed';
      window.SmartTrackDB.save(window.SmartTrackDB.load());

      // Issue active check-out
      var defaultDue = new Date();
      defaultDue.setDate(defaultDue.getDate() + 1);
      defaultDue.setHours(17, 0, 0, 0);

      window.SmartTrackDB.borrowItem({
        itemId: res.itemId,
        borrowerName: res.reservedBy,
        borrowerRole: res.reservedRole,
        department: res.department,
        purpose: res.purpose,
        expectedReturnDate: defaultDue.toISOString().slice(0, 16)
      });

      showToast(`Reserved asset ${res.itemId} released to ${res.reservedBy}!`, 'success');
      renderTimelineView();
      renderBorrowView();
      renderInventoryTable();
      renderDashboard();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  function cancelReservationConfirm(id) {
    if (confirm('Cancel this scheduled reservation?')) {
      window.SmartTrackDB.cancelReservation(id);
      showToast('Reservation cancelled.', 'info');
      renderTimelineView();
      renderDashboard();
    }
  }

  // ------------------------------------------------------------------
  // 7. BORROW & RETURN MODULE (Present & Past State)
  // ------------------------------------------------------------------
  function renderBorrowView() {
    var txns = window.SmartTrackDB.getTransactions();
    var tbody = document.getElementById('borrow-table-body');
    if (!tbody) return;

    var activeTxns = txns.filter(function(t) { return t.status === 'Active'; });
    var countElem = document.getElementById('borrow-active-count');
    if (countElem) countElem.innerText = `${activeTxns.length} In Custody`;

    if (txns.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; padding: 28px; color: #64748b;">No equipment movement transactions recorded yet. Click "Issue Equipment" to lend an asset.</td></tr>`;
      return;
    }

    tbody.innerHTML = txns.map(function(t) {
      var isAct = t.status === 'Active';
      var overdue = getOverdueDetails(t.expectedReturnDate);

      var bDate = new Date(t.borrowDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
      var expDate = t.expectedReturnDate ? new Date(t.expectedReturnDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'N/A';

      return `
        <tr style="${overdue.isOverdue && isAct ? 'background-color: #fef2f2;' : ''}">
          <td style="font-family: monospace; font-weight: 700;">${t.id}</td>
          <td>
            <strong>${t.itemName}</strong>
            <div style="font-size: 11px; color: #0284c7; font-family: monospace;">${t.itemId}</div>
          </td>
          <td>
            <strong>${t.borrowerName}</strong>
            <div style="font-size: 11px; color: #64748b;">${t.borrowerRole} (${t.department})</div>
          </td>
          <td>${bDate}</td>
          <td>
            ${expDate}
            ${overdue.isOverdue && isAct ? `<div style="color: #dc2626; font-size: 10.5px; font-weight: 700;">⚠️ ${overdue.text}</div>` : ''}
          </td>
          <td>
            <span class="badge ${isAct ? (overdue.isOverdue ? 'badge-under-maintenance' : 'badge-borrowed') : 'badge-returned'}">
              ${isAct ? (overdue.isOverdue ? 'Overdue' : 'Active') : 'Returned'}
            </span>
          </td>
          <td>
            ${isAct ? `
              <button class="btn btn-sm btn-success" onclick="window.SmartTrackApp.openReturnModal('${t.id}')">
                📥 Check-In / Return
              </button>
            ` : `<span style="font-size: 11px; color: #64748b;">Returned to Inventory</span>`}
          </td>
        </tr>
      `;
    }).join('');
  }

  function openBorrowModal(itemId) {
    var items = window.SmartTrackDB.getItems().filter(function(i) {
      return i.status === 'Available' || (itemId && i.id === itemId);
    });

    if (items.length === 0) {
      showToast('No assets are currently available to borrow.', 'info');
      return;
    }

    document.getElementById('form-borrow-modal').reset();
    var selectItem = document.getElementById('borrow-modal-item');
    selectItem.innerHTML = items.map(function(i) {
      return `<option value="${i.id}" ${itemId === i.id ? 'selected' : ''}>[${i.id}] ${i.name} (${i.room})</option>`;
    }).join('');

    var tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(17, 0, 0, 0);
    document.getElementById('borrow-modal-expected').value = tomorrow.toISOString().slice(0, 16);

    openModal('modal-borrow-item');
  }

  function saveBorrowForm(e) {
    if (e) e.preventDefault();
    var itemId = document.getElementById('borrow-modal-item').value;
    var borrowerName = document.getElementById('borrow-modal-name').value.trim();
    if (!itemId || !borrowerName) {
      showToast('Asset and Borrower Name are required.', 'error');
      return;
    }

    try {
      window.SmartTrackDB.borrowItem({
        itemId: itemId,
        borrowerName: borrowerName,
        borrowerRole: document.getElementById('borrow-modal-role').value,
        borrowerId: document.getElementById('borrow-modal-idnum').value.trim(),
        department: document.getElementById('borrow-modal-dept').value.trim(),
        purpose: document.getElementById('borrow-modal-purpose').value.trim(),
        expectedReturnDate: document.getElementById('borrow-modal-expected').value
      });

      closeModal('modal-borrow-item');
      showToast(`Asset ${itemId} successfully issued to ${borrowerName}!`, 'success');
      renderBorrowView();
      renderInventoryTable();
      renderTimelineView();
      renderDashboard();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  function openReturnModal(txnId) {
    var txns = window.SmartTrackDB.getTransactions();
    var txn = txns.find(function(t) { return t.id === txnId; });
    if (!txn) return;

    document.getElementById('return-modal-txnid').value = txn.id;
    document.getElementById('return-modal-item-info').innerText = `${txn.itemName} (${txn.itemId})`;
    document.getElementById('return-modal-borrower-info').innerText = `Issued to: ${txn.borrowerName} on ${new Date(txn.borrowDate).toLocaleDateString()}`;
    document.getElementById('return-modal-condition').value = 'Good';
    document.getElementById('return-modal-remarks').value = '';

    openModal('modal-return-item');
  }

  function openReturnModalByItemId(itemId) {
    var txns = window.SmartTrackDB.getTransactions();
    var activeTxn = txns.find(function(t) { return t.itemId.toUpperCase() === itemId.toUpperCase() && t.status === 'Active'; });
    if (activeTxn) openReturnModal(activeTxn.id);
    else showToast('No active borrow record found for ' + itemId, 'error');
  }

  function saveReturnForm(e) {
    if (e) e.preventDefault();
    var txnId = document.getElementById('return-modal-txnid').value;
    var condition = document.getElementById('return-modal-condition').value;
    var remarks = document.getElementById('return-modal-remarks').value.trim();

    try {
      window.SmartTrackDB.returnItem(txnId, condition, remarks);
      closeModal('modal-return-item');
      showToast('Asset returned and saved to Past History archive!', 'success');
      renderBorrowView();
      renderInventoryTable();
      renderTimelineView();
      renderDashboard();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  // ------------------------------------------------------------------
  // 8. ASSET CRUD & QR ENGINE
  // ------------------------------------------------------------------
  function openAddItemModal() {
    var form = document.getElementById('form-item-modal');
    if (form) form.reset();
    document.getElementById('modal-item-mode').value = 'add';
    document.getElementById('modal-item-title').innerText = 'Register School Asset';

    var items = window.SmartTrackDB.getItems();
    document.getElementById('modal-item-id').value = 'SCH-AST-' + String(items.length + 1).padStart(3, '0');
    document.getElementById('modal-item-id').removeAttribute('readonly');

    openModal('modal-add-item');
  }

  function openEditItemModal(id) {
    var item = window.SmartTrackDB.getItemById(id);
    if (!item) return;

    document.getElementById('modal-item-mode').value = 'edit';
    document.getElementById('modal-item-title').innerText = 'Edit Asset: ' + item.id;
    document.getElementById('modal-item-id').value = item.id;
    document.getElementById('modal-item-id').setAttribute('readonly', true);
    document.getElementById('modal-item-name').value = item.name;
    document.getElementById('modal-item-category').value = item.category;
    document.getElementById('modal-item-room').value = item.room;
    document.getElementById('modal-item-custodian').value = item.custodian || '';
    document.getElementById('modal-item-status').value = item.status;
    document.getElementById('modal-item-condition').value = item.condition;
    document.getElementById('modal-item-brand').value = item.brand || '';
    document.getElementById('modal-item-model').value = item.model || '';
    document.getElementById('modal-item-sn').value = item.serialNumber || '';
    document.getElementById('modal-item-cost').value = item.unitCost || 0;
    document.getElementById('modal-item-date').value = item.purchaseDate || '';
    document.getElementById('modal-item-supplier').value = item.supplier || '';
    document.getElementById('modal-item-notes').value = item.notes || '';

    openModal('modal-add-item');
  }

  function saveItemForm(e) {
    if (e) e.preventDefault();
    var id = document.getElementById('modal-item-id').value.trim().toUpperCase();
    var name = document.getElementById('modal-item-name').value.trim();
    if (!id || !name) {
      showToast('Asset ID and Item Name are required.', 'error');
      return;
    }

    var item = {
      id: id,
      name: name,
      category: document.getElementById('modal-item-category').value,
      room: document.getElementById('modal-item-room').value,
      custodian: document.getElementById('modal-item-custodian').value.trim(),
      status: document.getElementById('modal-item-status').value,
      condition: document.getElementById('modal-item-condition').value,
      brand: document.getElementById('modal-item-brand').value.trim(),
      model: document.getElementById('modal-item-model').value.trim(),
      serialNumber: document.getElementById('modal-item-sn').value.trim(),
      unitCost: parseFloat(document.getElementById('modal-item-cost').value) || 0,
      purchaseDate: document.getElementById('modal-item-date').value,
      supplier: document.getElementById('modal-item-supplier').value.trim(),
      notes: document.getElementById('modal-item-notes').value.trim()
    };

    window.SmartTrackDB.saveItem(item);
    closeModal('modal-add-item');
    showToast('Asset ' + item.id + ' saved successfully!', 'success');
    populateDropdowns();
    renderInventoryTable();
    renderDashboard();
  }

  function openItemDetails(id) {
    var item = window.SmartTrackDB.getItemById(id);
    if (!item) return;

    document.getElementById('details-item-id').innerText = item.id;
    document.getElementById('details-item-name').innerText = item.name;
    document.getElementById('details-item-cat').innerText = item.category;
    document.getElementById('details-item-room').innerText = item.room;
    document.getElementById('details-item-custodian').innerText = item.custodian || 'Unassigned';
    document.getElementById('details-item-status').innerHTML = `<span class="badge badge-${item.status.toLowerCase().replace(/\s+/g, '-')}">${item.status}</span>`;
    document.getElementById('details-item-condition').innerText = item.condition;
    document.getElementById('details-item-sn').innerText = item.serialNumber || 'N/A';
    document.getElementById('details-item-cost').innerText = formatCurrency(item.unitCost);

    var qrContainer = document.getElementById('details-qr-container');
    window.SmartTrackQR.renderQR(qrContainer, item.id, 180);

    var btnPrint = document.getElementById('details-btn-print-qr');
    if (btnPrint) {
      btnPrint.onclick = function() { window.SmartTrackExport.printBatchQRStickers([item]); };
    }

    var btnDownload = document.getElementById('details-btn-download-png');
    if (btnDownload) {
      btnDownload.onclick = function() { downloadAssetQRPng(item.id); };
    }

    var btnReserve = document.getElementById('details-btn-reserve');
    if (btnReserve) {
      btnReserve.onclick = function() {
        closeModal('modal-item-details');
        openReservationModal(item.id);
      };
    }

    openModal('modal-item-details');
  }

  // Download high-resolution PNG asset tag
  function downloadAssetQRPng(id) {
    var item = window.SmartTrackDB.getItemById(id);
    if (!item) return;

    var profile = window.SmartTrackDB.getSchoolProfile();
    var canvas = document.createElement('canvas');
    canvas.width = 400;
    canvas.height = 480;
    var ctx = canvas.getContext('2d');

    // White card background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, 400, 480);

    // Border
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 4;
    ctx.strokeRect(4, 4, 392, 472);

    // Header bar
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(4, 4, 392, 60);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 15px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(profile.schoolName.toUpperCase(), 200, 32);

    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 11px sans-serif';
    ctx.fillText('OFFICIAL SCHOOL INVENTORY ASSET', 200, 50);

    // Draw QR Code in Center
    var qrImg = new Image();
    qrImg.onload = function() {
      ctx.drawImage(qrImg, 80, 80, 240, 240);

      // Asset Tag ID
      ctx.fillStyle = '#0284c7';
      ctx.font = 'bold 20px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(item.id, 200, 345);

      // Item Name
      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 14px sans-serif';
      ctx.fillText(item.name.slice(0, 35), 200, 375);

      // Location & Custodian
      ctx.fillStyle = '#475569';
      ctx.font = '12px sans-serif';
      ctx.fillText(`Location: ${item.room}`, 200, 400);
      ctx.fillText(`Serial: ${item.serialNumber || 'N/A'} • Dept: ${item.category}`, 200, 420);

      // Footer
      ctx.fillStyle = '#dc2626';
      ctx.font = 'bold 10px sans-serif';
      ctx.fillText('★ PROPERTY OF SUPPLY OFFICE • DO NOT REMOVE ★', 200, 455);

      // Trigger download
      var a = document.createElement('a');
      a.href = canvas.toDataURL('image/png');
      a.download = `QR_Asset_${item.id}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      showToast(`QR Asset Tag PNG downloaded for ${item.id}`, 'success');
    };
    qrImg.src = window.SmartTrackQR.getQRDataUrl(item.id, 300);
  }

  function deleteItemConfirm(id) {
    if (confirm('Delete asset ' + id + ' from inventory?')) {
      window.SmartTrackDB.deleteItem(id);
      showToast('Asset ' + id + ' removed.', 'info');
      populateDropdowns();
      renderInventoryTable();
      renderDashboard();
    }
  }

  // ------------------------------------------------------------------
  // 9. ROOM AUDIT MODULE (Real-Time Verification & Misplaced Detection)
  // ------------------------------------------------------------------
  function initAuditView() {
    var select = document.getElementById('audit-select-room');
    if (select && select.value && activeAuditState) {
      renderAuditChecklist();
    }
  }

  function startRoomAudit() {
    var roomName = document.getElementById('audit-select-room').value;
    if (!roomName) {
      showToast('Please select a room to audit.', 'error');
      return;
    }

    var allItems = window.SmartTrackDB.getItems();
    var expected = allItems.filter(function(i) { return i.room === roomName; });

    activeAuditState = {
      roomName: roomName,
      startedAt: new Date().toISOString(),
      expectedItems: expected,
      scannedItemIds: {},
      misplacedItems: []
    };

    document.getElementById('audit-workspace').style.display = 'block';
    document.getElementById('audit-room-title').innerText = roomName;
    renderAuditChecklist();
    showToast(`Audit started for ${roomName} (${expected.length} expected). Ready to scan!`, 'info');
  }

  function handleAuditItemScan(scannedCode) {
    if (!activeAuditState) return;
    scannedCode = scannedCode.trim().toUpperCase();
    var item = window.SmartTrackDB.getItemById(scannedCode);

    if (!item) {
      playBeep(false);
      showToast('Unregistered item tag: ' + scannedCode, 'error');
      return;
    }

    // Check if the item belongs to this room
    if (item.room === activeAuditState.roomName) {
      activeAuditState.scannedItemIds[scannedCode] = true;
      playBeep(true);
      showToast(`Verified present: ${item.name} (${item.id})`, 'success');
    } else {
      // Misplaced item alert!
      playBeep(false);
      var alreadyLogged = activeAuditState.misplacedItems.some(function(m) { return m.id === item.id; });
      if (!alreadyLogged) {
        activeAuditState.misplacedItems.push(item);
      }
      showToast(`⚠️ Misplaced Item! ${item.id} belongs in ${item.room}, found here!`, 'error');
    }

    renderAuditChecklist();
  }

  function renderAuditChecklist() {
    if (!activeAuditState) return;
    var expected = activeAuditState.expectedItems;
    var scannedIds = activeAuditState.scannedItemIds;
    var verifiedCount = 0;

    var container = document.getElementById('audit-items-list');
    if (!container) return;

    if (expected.length === 0 && activeAuditState.misplacedItems.length === 0) {
      container.innerHTML = `<div style="padding: 24px; text-align: center; color: #64748b;">No assets registered to ${activeAuditState.roomName} yet.</div>`;
      return;
    }

    var listHtml = expected.map(function(item) {
      var isVerified = Boolean(scannedIds[item.id]);
      if (isVerified) verifiedCount++;
      return `
        <div class="audit-item-row" style="padding: 10px 14px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; background: ${isVerified ? '#f0fdf4' : '#ffffff'};">
          <div>
            <strong>${item.name}</strong> (${item.id})
            <div style="font-size: 11px; color: #64748b;">Category: ${item.category} • Serial: ${item.serialNumber || 'N/A'}</div>
          </div>
          <div>
            ${isVerified ? 
              '<span class="badge badge-available">✅ VERIFIED FOUND</span>' : 
              `<button class="btn btn-sm btn-secondary" onclick="window.SmartTrackApp.manualVerifyAuditItem('${item.id}')">Manual Mark</button>`
            }
          </div>
        </div>
      `;
    }).join('');

    // Append misplaced items if any were scanned
    if (activeAuditState.misplacedItems.length > 0) {
      listHtml += '<div style="padding: 10px 14px; background: #fff1f2; font-weight: 700; color: #991b1b; font-size: 12px; margin-top: 8px;">⚠️ Misplaced Assets Found in This Room:</div>';
      listHtml += activeAuditState.misplacedItems.map(function(m) {
        return `
          <div style="padding: 10px 14px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; background: #fff1f2;">
            <div>
              <strong>${m.name}</strong> (${m.id})
              <div style="font-size: 11px; color: #991b1b;">Registered Location: <strong>${m.room}</strong></div>
            </div>
            <div>
              <button class="btn btn-sm btn-danger" onclick="window.SmartTrackApp.transferItemRoom('${m.id}', '${activeAuditState.roomName}')">Transfer to this Room</button>
            </div>
          </div>
        `;
      }).join('');
    }

    container.innerHTML = listHtml;
    var total = expected.length;
    var pct = total > 0 ? Math.round((verifiedCount / total) * 100) : 100;
    document.getElementById('audit-progress-bar').style.width = pct + '%';
    document.getElementById('audit-progress-text').innerText = `${verifiedCount} of ${total} verified (${pct}%)`;
  }

  function manualVerifyAuditItem(id) {
    if (!activeAuditState) return;
    activeAuditState.scannedItemIds[id] = true;
    playBeep(true);
    renderAuditChecklist();
    showToast('Marked ' + id + ' as physically verified.', 'info');
  }

  function transferItemRoom(id, targetRoom) {
    var item = window.SmartTrackDB.getItemById(id);
    if (!item) return;
    item.room = targetRoom;
    window.SmartTrackDB.saveItem(item);
    showToast(`Asset ${id} officially transferred to ${targetRoom}.`, 'success');

    if (activeAuditState) {
      activeAuditState.misplacedItems = activeAuditState.misplacedItems.filter(function(m) { return m.id !== id; });
      activeAuditState.expectedItems.push(item);
      activeAuditState.scannedItemIds[id] = true;
      renderAuditChecklist();
    }
    renderInventoryTable();
  }

  function finishRoomAudit() {
    if (!activeAuditState) return;
    var expected = activeAuditState.expectedItems;
    var scannedCount = Object.keys(activeAuditState.scannedItemIds).length;
    var missingCount = expected.length - scannedCount;

    window.SmartTrackDB.saveAuditRecord({
      roomName: activeAuditState.roomName,
      auditDate: new Date().toISOString().slice(0, 10),
      auditor: window.SmartTrackDB.getCurrentUser().fullName,
      totalExpected: expected.length,
      scannedCount: scannedCount,
      missingCount: missingCount,
      status: missingCount === 0 ? 'Passed (100%)' : 'Discrepancy'
    });

    showToast(`Audit for ${activeAuditState.roomName} completed and archived!`, 'success');
    activeAuditState = null;
    document.getElementById('audit-workspace').style.display = 'none';
  }

  // ------------------------------------------------------------------
  // 10. SCHOOL SETTINGS & DATA CONTROLS
  // ------------------------------------------------------------------
  function renderSettingsView() {
    var profile = window.SmartTrackDB.getSchoolProfile();
    document.getElementById('set-school-name').value = profile.schoolName || '';
    document.getElementById('set-subtitle').value = profile.subTitle || '';
    document.getElementById('set-custodian').value = profile.custodianOfficer || '';
    document.getElementById('set-head').value = profile.schoolHead || '';
    document.getElementById('set-currency').value = profile.currency || '₱';
  }

  function saveSettings(e) {
    if (e) e.preventDefault();
    window.SmartTrackDB.saveSchoolProfile({
      schoolName: document.getElementById('set-school-name').value.trim(),
      subTitle: document.getElementById('set-subtitle').value.trim(),
      custodianOfficer: document.getElementById('set-custodian').value.trim(),
      schoolHead: document.getElementById('set-head').value.trim(),
      currency: document.getElementById('set-currency').value.trim() || '₱'
    });
    showToast('School profile configuration saved!', 'success');
    document.getElementById('topbar-school-name').innerText = document.getElementById('set-school-name').value.trim();
    renderDashboard();
  }

  function clearAllDataConfirm() {
    if (confirm('Are you sure you want to completely erase and blank the database? All items, history, and records will be cleared.')) {
      window.SmartTrackDB.clearAllData();
      showToast('Database wiped blank and empty.', 'info');
      populateDropdowns();
      navigateTo('dashboard');
    }
  }

  function populateDropdowns() {
    var categories = window.SmartTrackDB.getCategories();
    var rooms = window.SmartTrackDB.getRooms();

    var catSelect = document.getElementById('inv-filter-cat');
    if (catSelect) {
      catSelect.innerHTML = '<option value="">All Categories</option>' + categories.map(function(c) {
        return `<option value="${c.name}">${c.name}</option>`;
      }).join('');
    }

    var roomSelect = document.getElementById('inv-filter-room');
    if (roomSelect) {
      roomSelect.innerHTML = '<option value="">All Rooms</option>' + rooms.map(function(r) {
        return `<option value="${r.name}">${r.name}</option>`;
      }).join('');
    }

    var mCat = document.getElementById('modal-item-category');
    if (mCat) {
      mCat.innerHTML = categories.map(function(c) {
        return `<option value="${c.name}">${c.name}</option>`;
      }).join('');
    }

    var mRoom = document.getElementById('modal-item-room');
    if (mRoom) {
      mRoom.innerHTML = rooms.map(function(r) {
        return `<option value="${r.name}">${r.name}</option>`;
      }).join('');
    }

    var audRoom = document.getElementById('audit-select-room');
    if (audRoom) {
      audRoom.innerHTML = '<option value="">-- Choose Room to Audit --</option>' + rooms.map(function(r) {
        return `<option value="${r.name}">${r.name} (${r.building})</option>`;
      }).join('');
    }
  }

  function init() {
    populateDropdowns();
    updateCurrentUserDisplay();
    var profile = window.SmartTrackDB.getSchoolProfile();
    var schoolElem = document.getElementById('topbar-school-name');
    if (schoolElem) schoolElem.innerText = profile.schoolName;

    navigateTo('dashboard');

    // Hardware USB barcode gun scanner listener
    window.SmartTrackQR.listenToBarcodeGun(function(code) {
      handleScannedItemCode(code);
    });

    // Dropzone for QR image upload
    var dropzone = document.getElementById('qr-upload-dropzone');
    var fileInput = document.getElementById('qr-file-input');
    if (dropzone && fileInput) {
      dropzone.onclick = function() { fileInput.click(); };
      fileInput.onchange = function(e) {
        if (e.target.files && e.target.files[0]) {
          showToast('Scanning uploaded QR image...', 'info');
          window.SmartTrackQR.decodeImageFile(
            e.target.files[0],
            function(code) { handleScannedItemCode(code); },
            function(err) { showToast(err, 'error'); }
          );
        }
      };
    }

    // JSON Database Restore
    var restoreInput = document.getElementById('import-json-input');
    if (restoreInput) {
      restoreInput.onchange = function(e) {
        if (e.target.files && e.target.files[0]) {
          var reader = new FileReader();
          reader.onload = function(evt) {
            try {
              window.SmartTrackDB.importDatabaseJson(evt.target.result);
              showToast('Database backup restored successfully!', 'success');
              populateDropdowns();
              refreshAllViews();
            } catch (err) {
              showToast('Restore error: ' + err.message, 'error');
            }
          };
          reader.readAsText(e.target.files[0]);
        }
      };
    }

    // Live search on keystroke
    var searchInput = document.getElementById('inv-search-input');
    if (searchInput) searchInput.oninput = renderInventoryTable;
    var catF = document.getElementById('inv-filter-cat');
    if (catF) catF.onchange = renderInventoryTable;
    var rmF = document.getElementById('inv-filter-room');
    if (rmF) rmF.onchange = renderInventoryTable;
    var stF = document.getElementById('inv-filter-status');
    if (stF) stF.onchange = renderInventoryTable;
  }

  // Public API
  window.SmartTrackApp = {
    init: init,
    navigateTo: navigateTo,
    setTimelineFilter: setTimelineFilter,
    openModal: openModal,
    closeModal: closeModal,
    openItemDetails: openItemDetails,
    downloadAssetQRPng: downloadAssetQRPng,
    openAddItemModal: openAddItemModal,
    openEditItemModal: openEditItemModal,
    saveItemForm: saveItemForm,
    deleteItemConfirm: deleteItemConfirm,
    toggleCameraScanner: toggleCameraScanner,
    flipCamera: flipCamera,
    toggleTorch: toggleTorch,
    handleManualScanLookup: handleManualScanLookup,
    handleScannedItemCode: handleScannedItemCode,
    openBorrowModal: openBorrowModal,
    saveBorrowForm: saveBorrowForm,
    openReturnModal: openReturnModal,
    saveReturnForm: saveReturnForm,
    openReservationModal: openReservationModal,
    saveReservationForm: saveReservationForm,
    releaseReservationNow: releaseReservationNow,
    cancelReservationConfirm: cancelReservationConfirm,
    openRegisterUserModal: openRegisterUserModal,
    saveUserForm: saveUserForm,
    deleteUserConfirm: deleteUserConfirm,
    switchActiveUser: switchActiveUser,
    startRoomAudit: startRoomAudit,
    manualVerifyAuditItem: manualVerifyAuditItem,
    transferItemRoom: transferItemRoom,
    finishRoomAudit: finishRoomAudit,
    saveSettings: saveSettings,
    clearAllDataConfirm: clearAllDataConfirm,
    showToast: showToast
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})(window);
