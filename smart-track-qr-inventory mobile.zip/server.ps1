# SmartTrack Pure PowerShell HTTP Server (Zero Dependencies, Zero Node/Python needed)
param([int]$Port = 8080)

$Root = $PSScriptRoot
if (-not $Root) { $Root = (Get-Location).Path }

# Get local IP address
$LocalIP = "localhost"
try {
    $ipConfig = ipconfig
    foreach ($line in ($ipConfig -split "`n")) {
        if ($line -match "IPv4 Address[ .:]+([\d\.]+)") {
            $candidate = $matches[1].Trim()
            if ($candidate -notlike "169.254*" -and $candidate -ne "127.0.0.1") {
                $LocalIP = $candidate
                break
            }
        }
    }
} catch {}

$Listener = New-Object System.Net.HttpListener
$Listener.Prefixes.Add("http://+:$Port/")
try {
    $Listener.Start()
} catch {
    # Fallback to localhost if wildcard fails due to permissions
    $Listener = New-Object System.Net.HttpListener
    $Listener.Prefixes.Add("http://localhost:$Port/")
    $Listener.Start()
}

Write-Host "=================================================================" -ForegroundColor Cyan
Write-Host "  SMARTTRACK QR SCHOOL INVENTORY - LIVE MOBILE WEB SERVER" -ForegroundColor Green
Write-Host "=================================================================" -ForegroundColor Cyan
Write-Host " [PC Access]:       http://localhost:$Port/" -ForegroundColor Yellow
Write-Host " [Phone Access]:    http://${LocalIP}:$Port/" -ForegroundColor Green
Write-Host "=================================================================" -ForegroundColor Cyan
Write-Host " Connect your phone to the same Wi-Fi and open the Phone Access URL!" -ForegroundColor White
Write-Host " Press Ctrl+C in this window to stop the server.`n" -ForegroundColor Gray

# Open default browser
try { Start-Process "http://localhost:$Port/" } catch {}

$MimeTypes = @{
    ".html" = "text/html; charset=utf-8"
    ".css"  = "text/css; charset=utf-8"
    ".js"   = "application/javascript; charset=utf-8"
    ".json" = "application/json; charset=utf-8"
    ".png"  = "image/png"
    ".jpg"  = "image/jpeg"
    ".svg"  = "image/svg+xml"
    ".ico"  = "image/x-icon"
}

while ($Listener.IsListening) {
    try {
        $Context = $Listener.GetContext()
        $Request = $Context.Request
        $Response = $Context.Response

        $UrlPath = $Request.Url.LocalPath
        if ($UrlPath -eq "/" -or $UrlPath -eq "") {
            $UrlPath = "/index.html"
        }

        $CleanPath = $UrlPath.TrimStart('/').Replace('/', [System.IO.Path]::DirectorySeparatorChar)
        $FilePath = Join-Path $Root $CleanPath

        if (Test-Path $FilePath -PathType Leaf) {
            $Ext = [System.IO.Path]::GetExtension($FilePath).ToLower()
            $ContentType = $MimeTypes[$Ext]
            if (-not $ContentType) { $ContentType = "application/octet-stream" }
            $Response.ContentType = $ContentType

            # Enable CORS & Mobile Permissions
            $Response.AddHeader("Access-Control-Allow-Origin", "*")
            $Response.AddHeader("Cache-Control", "no-cache, no-store, must-revalidate")

            $Bytes = [System.IO.File]::ReadAllBytes($FilePath)
            $Response.ContentLength64 = $Bytes.Length
            $Response.OutputStream.Write($Bytes, 0, $Bytes.Length)
        } else {
            $Response.StatusCode = 404
            $NotFound = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found")
            $Response.OutputStream.Write($NotFound, 0, $NotFound.Length)
        }
        $Response.OutputStream.Close()
    } catch {
        # Continue loop on aborted client connection
    }
}
