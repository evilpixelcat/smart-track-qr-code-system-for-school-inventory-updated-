# SmartTrack: QR Code System for School Inventory (Mobile & Desktop)

[![Mobile Ready](https://img.shields.io/badge/Mobile-Web%20App%20%2B%20PWA-purple.svg)](file:///mobile.html)
[![Live Server](https://img.shields.io/badge/Live%20Server-Zero%20Dependency%20HTTP-success.svg)](file:///start-mobile-server.bat)
[![Database](https://img.shields.io/badge/Database-Persistent%20Browser%20DB-blue.svg)](file:///index.html)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](file:///README.md)

**SmartTrack** is an automated, exportable School Property and Asset Inventory Management System designed for both desktop workstations and mobile smartphones. It features instant QR code generation, mobile camera scanning with permissions, a Past/Present/Future asset lifecycle timeline, and an official reporting engine.

---

## 📱 How to Run the Actual Live Mobile Site on Your Phone

You don't need any special app store download—you can run it as an actual mobile website:

### Method 1: One-Click Mobile Server Launcher (Recommended)
1. In this project folder, double-click **`start-mobile-server.bat`**.
2. It starts a lightweight HTTP server on port 8080 and displays:
   - **PC Access**: `http://localhost:8080/`
   - **Phone Access (Same Wi-Fi)**: `http://192.168.1.200:8080/mobile.html`
3. On your phone (iPhone Safari or Android Chrome connected to the same Wi-Fi), type that address or scan the on-screen QR code!
4. **Camera Permissions**: When prompted by Safari or Chrome, tap **"Allow"** to scan QR tags using your phone camera!

### Method 2: Direct Browser Launch
- Open **[mobile.html](file:///C:/Users/Junar/.gemini/antigravity/scratch/smart-track-inventory/mobile.html)** directly in your browser or mobile emulator.
- Open **[index.html](file:///C:/Users/Junar/.gemini/antigravity/scratch/smart-track-inventory/index.html)** for the full desktop portal.

---

## 📦 Project File Structure

```
smart-track-inventory/
├── mobile.html                                # Dedicated Smartphone Mobile Web App
├── index.html                                 # Full Desktop & Tablet Web Portal
├── start-mobile-server.bat                    # One-Click Live Web Server Launcher for Phones
├── server.ps1                                 # Native Windows PowerShell HTTP Web Server
├── manifest.json                              # Progressive Web App (PWA) Manifest
├── run.bat                                    # Desktop Browser Launcher
├── css/
│   └── styles.css                             # Mobile-first CSS with Bottom Navigation Dock
├── js/
│   ├── app.js                                 # State Controller & Real-Time Sync
│   ├── db.js                                  # Persistent Database (Accounts + Items)
│   ├── qr-engine.js                           # Mobile Camera Scanner, Flip, Torch & Sound
│   ├── export-engine.js                       # CSV, Excel, RPCPPE PDF Reports & A4 Stickers
│   └── vendor/
│       └── qrcode.js                          # Pure JavaScript QR Code Generator
├── templates/
│   └── printable_stickers_sheet.html          # Standalone A4 QR Sticker Sheet Generator
├── docs/                                      # Capstone Research & Defense Suite
│   ├── 01_CAPSTONE_PROJECT_MANUSCRIPT.md      # Full Chapters 1 to 5 Research Paper
│   ├── 02_DATABASE_DATA_DICTIONARY.md         # Detailed Table & Field Specifications
│   ├── 03_USER_MANUAL_AND_OPERATIONS_GUIDE.md # User & Custodian Guide
│   └── 04_CAPSTONE_DEFENSE_QA_AND_SLIDES.md   # Presentation Slides Script + 15 Panel Defense Q&A
└── backend-alternative/                       # Client-Server Architecture (Optional for panel)
    ├── server.js                              # Express.js REST API Microservice
    ├── database_schema.sql                    # Production-ready MySQL/PostgreSQL/SQLite DDL
    └── package.json
```

---

## 🌟 Key Features

1. **📱 Dedicated Mobile Web App (`mobile.html`)**:
   - Native mobile bottom dock: 🏠 Home, 📋 Assets, 📷 Scan, ⏳ Timeline, 👤 Account.
   - Rear-camera focus (`facingMode: "environment"`), Flip Camera, and Torch/Flashlight toggle.
   - PWA ready: can be saved to smartphone home screen as an app icon.
2. **⏳ Past / Present / Future Timeline**:
   - **Future**: Schedule equipment reservations for upcoming dates with 1-click checkout.
   - **Present**: Active checkouts with real-time overdue timers (`Overdue by X hours`).
   - **Past**: Completed return history with inspection condition notes (`Good`, `Fair`, `Needs Repair`).
3. **📍 Physical Room Audit Mode**:
   - Live checklist with instant visual green checkmarks.
   - Automatic detection of **misplaced assets** with 1-click room transfer.
4. **💾 Persistent Database & User Accounts**:
   - Multiple roles: Administrator, Custodian, Faculty, Staff, Student.
   - Browser storage retains all records permanently.
5. **🖨️ Multi-Format Export Center**:
   - Excel-ready CSV with UTF-8 BOM.
   - Official Government/Institutional RPCPPE report (Print / PDF).
   - High-density A4 QR sticker sheets.
   - Full JSON database backup and restore.
