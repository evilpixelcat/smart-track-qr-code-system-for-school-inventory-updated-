@echo off
title SmartTrack Mobile Web Server
echo =========================================================================
echo   Starting SmartTrack Live Web Server for PC and Mobile Phones...
echo =========================================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
pause
